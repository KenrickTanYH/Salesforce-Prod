({
    initialize : function(component, event, helper) {
        helper.getRecord(component,event);
	},
    
	saveRequest : function(component, event, helper) {
         var action=component.get("c.getCourseRunRec");
        action.setParams({
            'courseRegId':component.get("v.recordId") 
        });
        action.setCallback(this,function(response){
            if(response.getState()=='SUCCESS'){
                if(response.getReturnValue() != null){
                    component.set("v.courseReg",response.getReturnValue());
                    if(component.get("v.courseReg").Course_Run_Id__r.SSG_Course_Run_ID__c != null 
                       && component.get("v.courseReg").Course_Run_Id__r.SSG_Course_Run_ID__c !=''){
                        if(event.getSource().get("v.name")=='SyncEnrollment'){
                            helper.helperSubmitSynchEnrolment(component, event);
                        }else if(event.getSource().get("v.name")=='CheckGrants'){
                            helper.helperSubmitCheckGrants(component, event);
                        }
                    }else{
                        helper.helperCallToastMsg(component, event,'Error!','error',$A.get("$Label.c.SSG_Course_Run_ID_Validation")); 
                    }
                }   
            }else{
                //component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_CourseReg_Integration"));
            }
        });
        $A.enqueueAction(action);
	},
    closeModel: function(component, event, helper) {
      // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpen", false);
        component.set("v.isError",false);
   }
})