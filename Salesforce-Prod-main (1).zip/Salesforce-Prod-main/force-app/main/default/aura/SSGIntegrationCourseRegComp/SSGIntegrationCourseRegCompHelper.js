({
	helperSubmitSynchEnrolment: function(component,event) {
        component.set("v.showSpinner",true);
		var action = component.get("c.submitRequestSynchEnrolment");
        action.setParams({
            'courseRegId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue().includes("SUCCESS")){
                component.set("v.showSpinner",false);
                component.set("v.isOpen", true);
                component.set("v.successMsg", $A.get("$Label.c.Success_Message_SSGCourseregIntegration"));
            }else{
                component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_CourseReg_Integration"));
            }
        });
        
        $A.enqueueAction(action);
	},
    helperSubmitCheckGrants: function(component,event) {
        component.set("v.showSpinner",true);
		var action = component.get("c.submitRequestCheckGrant");
        action.setParams({
            'courseRegId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue().includes("SUCCESS")){
                component.set("v.showSpinner",false);
                component.set("v.isOpen", true);
                component.set("v.successMsg", $A.get("$Label.c.Success_Message_SSGCourseregIntegration"));
            }else{
                component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_CourseReg_Integration"));
            }
        });
        
        $A.enqueueAction(action);
	},
    getRecord:function(component,event){
        var action=component.get("c.getCourseRunRec");
        action.setParams({
            'courseRegId':component.get("v.recordId") 
        });
        action.setCallback(this,function(response){
            if(response.getState()=='SUCCESS'){
                if(response.getReturnValue() != null){
                    component.set("v.courseReg",response.getReturnValue());
                }   
            }
        });
        $A.enqueueAction(action);
    },
    helperCallToastMsg:function(component,event,title,errorType,errorMsg){
        var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type":errorType,
                "title":title,
                "message": errorMsg
            });
            toastEvent.fire();  
    }
})