({
    addJDRecord: function(component, event, helper) {
        var jdList = component.get("v.jdList");
        jdList.push({
            'sobjectType': 'Session__c',
            'Session_Date__c': '',
            'Start_Time__c': '8:00 AM',
            'End_Time__c' : '5:00 PM',
            'Mode_of_Training__c' : '1',
            'Course_Run__c': component.get('v.CourseRunId')
        });
        component.set("v.jdList", jdList);
    },     
    validateJDList: function(component, event) {
        var isValid = true;
        var jdList = component.get("v.jdList");
        if(jdList.length == 0)
            isValid = false;  
        for (var i = 0; i < jdList.length; i++) {
            if ($A.util.isEmpty(jdList[i].Session_Date__c) || 
                $A.util.isEmpty(jdList[i].Start_Time__c) || 
                $A.util.isEmpty(jdList[i].End_Time__c) ||
                 $A.util.isEmpty(jdList[i].Mode_of_Training__c))
            {
                isValid = false;               
            }
        }
        if(isValid == false){            
            this.showToast(component, event, 'error'); 
        }        
        return isValid;
    },     
    saveJDList: function(component, event, helper) {
        var action = component.get("c.createCourseRunJumpingDates");  
        action.setParams({
            "eJumpingDatesList": component.get("v.jdList")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();            
            if (state === "SUCCESS") {
                this.showToast(component, event, 'pass');	
                component.set("v.jdList", []);
                component.set("v.AddDatesChild", false);
            }else{
                var errors = response.getError();
               // alert(errors[0].message.split('FIELD_CUSTOM_VALIDATION_EXCEPTION,')[1]);
                this.showToast(component, event, errors[0].message.split('FIELD_CUSTOM_VALIDATION_EXCEPTION,')[1]); 
            }
        }); 
        $A.enqueueAction(action);
    },
    showToast: function(component, event, status){
        if(status == 'pass'){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Success!",
                "message": "Dates added successfully",
                "type" : "success"
            });
            toastEvent.fire(); 
            $A.get("e.force:closeQuickAction").fire();
            $A.get('e.force:refreshView').fire(); 
        }else if(status == 'error'){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": "Please ensure Date, Time and Mode of Training are filled",
                "type" : "error"
            });
            toastEvent.fire();  
        }else{
            component.set('v.spinner', false);
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": status,
                "type" : "error"
            });
            toastEvent.fire();  
        }
    }
})