({
    doInit: function(component, event, helper) {
        helper.addJDRecord(component, event);
    },
    
    addRow: function(component, event, helper) {
        helper.addJDRecord(component, event);
    },     
    removeRow: function(component, event, helper) {
        var jdList = component.get("v.jdList");
        var selectedItem = event.currentTarget;
        var index = selectedItem.dataset.record;
        jdList.splice(index, 1);
        component.set("v.jdList", jdList);
    },     
    save: function(component, event, helper) {         
        if (helper.validateJDList(component, event)) {
            component.set('v.spinner', true);
            helper.saveJDList(component, event);
        }
    },
    cancel: function(component, event, helper) {
      $A.get("e.force:closeQuickAction").fire();
   }
})