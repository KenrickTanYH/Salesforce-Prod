({  
    
    onInit : function( component, event, helper ) {    
        $A.get("e.force:closeQuickAction").fire();
        
        let action = component.get( "c.sendEmail" );  
        action.setParams({  
            recId: component.get( "v.recordId" )
        });  
        action.setCallback(this, function(response) {  
            let state = response.getState();  
            if ( state === "SUCCESS" ) {  
                
                $A.get("e.force:closeQuickAction").fire();  
                $A.get('e.force:refreshView').fire();  
                console.log('Success');
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Success',
                    message: 'Promo Code Sent !!',
                    type: 'success'
                });
                toastEvent.fire();
                
            }  else {
                console.log('Error');
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Error',
                    message: 'Please select the Account to send the Promo Code',
                    key: 'info_alt',
                    type: 'error',
                    mode: 'pester'
                });
                toastEvent.fire();
                
            }
        });  
        $A.enqueueAction( action );         
        
    }
    
})