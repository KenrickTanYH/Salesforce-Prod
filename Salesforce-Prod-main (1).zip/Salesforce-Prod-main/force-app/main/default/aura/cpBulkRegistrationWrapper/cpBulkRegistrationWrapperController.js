({
    initialize: function (component, event, helper) {
        console.log('Initialize');
        var query = location.search.substr(1);
        var result = {};
        query.split("&").forEach(function (part) {
            var item = part.split("=");
            result[item[0]] = decodeURIComponent(item[1]);
        });
        let crCode = result.courseruncode;
        // Get the user information - SPOC
        var action = component.get("c.getUserRec");
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                let userInfo = response.getReturnValue();
                console.log('userInfo' + userInfo.ContactId + crCode);
                let spocObj = { 'selectedContactId': userInfo.ContactId, 'courseRunCode': crCode, 'isInternal': false };
                component.set('v.isShow', true);
                component.set('v.spocObj', spocObj);
                console.log(JSON.stringify(spocObj));

            }
        });
        $A.enqueueAction(action);
    }
})