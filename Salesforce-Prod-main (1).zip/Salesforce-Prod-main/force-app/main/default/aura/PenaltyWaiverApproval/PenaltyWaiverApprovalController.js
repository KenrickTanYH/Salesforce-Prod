({
	initialize : function(component, event, helper) {
		helper.checkSubmitForApproval(component,event);
	},
    saveRequest: function(component, event, helper) {
		helper.SubmitForApproval(component,event);
	},
    closeModel: function(component, event, helper) {
      // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpen", false);
        component.set("v.isError",false);
   }
})