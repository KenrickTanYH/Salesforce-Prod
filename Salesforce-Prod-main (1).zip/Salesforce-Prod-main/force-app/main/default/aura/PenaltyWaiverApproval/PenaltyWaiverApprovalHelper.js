({
	checkSubmitForApproval : function(component,event) {
		var action = component.get("c.checkRecordApplicablity");
        action.setParams({
            'courseRegId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue()!= null){
                component.set("v.isPenalty",response.getReturnValue());
            }
        });
        
        $A.enqueueAction(action);
	},
    SubmitForApproval: function(component,event) {
        component.set("v.showSpinner",true);
		var action = component.get("c.submitForApproval");
        action.setParams({
            'courseRegId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue().includes("SUCCESS")){
                component.set("v.showSpinner",false);
                component.set("v.isOpen", true);
                component.set("v.successMsg", 'The Record has been Successfuly Submitted');
            }else{
                component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", 'Please Contact System admin');
            }
        });
        
        $A.enqueueAction(action);
	}
})