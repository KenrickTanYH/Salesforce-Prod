({
	helperFetchClaimStatus: function(component,event) {
        component.set("v.showSpinner",true);
		var action = component.get("c.FetchClaimStatus");
        action.setParams({
            'courseRegId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue().includes("SUCCESS")){
                component.set("v.showSpinner",false);
                component.set("v.isOpen", true);
                component.set("v.successMsg", $A.get("$Label.c.Success_Message_SSGCourseregIntegration"));
            }else{
                component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_CourseReg_Integration"));
            }
        });
        
        $A.enqueueAction(action);
	},
    helperCancelClaim: function(component,event) {
        component.set("v.showSpinner",true);
		var action = component.get("c.CancelClaim");
        action.setParams({
            'courseRegId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue().includes("SUCCESS")){
                component.set("v.showSpinner",false);
                component.set("v.isOpen", true);
                component.set("v.successMsg", $A.get("$Label.c.Success_Message_SSGCourseregIntegration"));
            }else{
                component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_CourseReg_Integration"));
            }
        });
        
        $A.enqueueAction(action);
	},
    getRecord:function(component,event){
        var action=component.get("c.getCourseRegistration");
        action.setParams({
            'courseRegId':component.get("v.recordId") 
        });
        action.setCallback(this,function(response){
            if(response.getState()=='SUCCESS'){
                if(response.getReturnValue() != null){
                    component.set("v.courseReg",response.getReturnValue());
                    if(response.getReturnValue().Learner_Fundings__r!=null && response.getReturnValue().Learner_Fundings__r.length>0){
                    	component.set("v.showButtons","true");
                    }
                }   
            }
        });
        $A.enqueueAction(action);
    },
    helperCallToastMsg:function(component,event,title,errorType,errorMsg){
        var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type":errorType,
                "title":title,
                "message": errorMsg
            });
            toastEvent.fire();  
    }
})