({
    initialize : function(component, event, helper) {
        helper.getRecord(component,event);
	},
    
	saveRequest : function(component, event, helper) {
         var action=component.get("c.getCourseRegistration");
        action.setParams({
            'courseRegId':component.get("v.recordId") 
        });
        action.setCallback(this,function(response){
            if(response.getState()=='SUCCESS'){
                if(response.getReturnValue() != null){
                    component.set("v.courseReg",response.getReturnValue());
                    if(event.getSource().get("v.name")=='FetchClaimStatus'){
                        helper.helperFetchClaimStatus(component, event);
                    }else if(event.getSource().get("v.name")=='CancelClaim'){
                        helper.helperCancelClaim(component, event);
                    }
                }   
            }else{
                //component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_CourseReg_Integration"));
            }
        });
        $A.enqueueAction(action);
	},
    closeModel: function(component, event, helper) {
      // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpen", false);
        component.set("v.isError",false);
   }
})