({	
    getJsonFromUrl : function () {
        
        var result = window.location.href.split('/')[5];
        // console.log('window   '+window.location.href.split('/')[5]);
        return result;
    },
    // var vfHost = window.location.href.split('/')[0]+'//'+window.location.href.split('/')[2];
    
    
    
    createLearnerFunding : function(component, event) { 
        //console.log('createLearnerFunding ');
        var buttonLabel = component.get('v.buttonlabel');
        //console.log('buttonlabel '+component.get('v.buttonlabel'));
        var courseRegId = component.get("v.courseRegistrationId");
        //console.log('courseRegistrationId '+component.get('v.courseRegistrationId'));   
        
        if($A.util.isEmpty(component.get("v.validFundingList"))) {
            /*   if(buttonLabel == 'Draft'){
                component.set("v.isDraftOpen", true);    
            } */
            
            if(buttonLabel == 'Draft') {
                component.set("v.isExecutiveModalOpen", true);
            }
            
        }
        else {
            //console.log('validFundingList '+component.get("v.validFundingList"));
            //console.log('cRegid '+component.get("v.courseRegistrationId"));
            var action = component.get('c.insertFundingRecords');
            action.setParams({learnerFundList: component.get("v.validFundingList"),
                              courseRegId: courseRegId});
            action.setCallback(this, function(response) {
                if(response.getState() === "SUCCESS") {
                    // alert('Learner Funding records created successfully');
                    /* if(buttonLabel == 'Draft'){
                        component.set("v.isDraftOpen", true);    
                    } */
                    
                    
                    if(buttonLabel == 'Draft') {
                        component.set("v.isExecutiveModalOpen", true);               
                    }
                    
                    
                } else if(response.getState() == "ERROR"){
                    var errors = response.getError();    
                    console.log(errors[0].message);
                }
            });
            $A.enqueueAction(action);
        }          
        
    },
    
    createModal : function(component, title, message, confirmHandler, showCancel) {
        $A.createComponent(
            "c:Modal_Confirmation",
            {
                "title": title,
                "message": message,
                "confirm": component.getReference(confirmHandler),
                "showCancel": showCancel
            },
            function(modalWindow, status, errorMessage){
                if (status === "SUCCESS") {
                    var modalBody = component.set("v.modalBody", modalWindow);
                }
                else if (status === "INCOMPLETE") {
                    console.log("No response from server or client is offline.")
                    // Show offline error
                }
                    else if (status === "ERROR") {
                        console.log("Error: " + errorMessage);
                        // Show error message
                    }
            }
        );
    },
    
    checkUserProfile:function(component,event,code){
        var action =component.get("c.checkUserProfile");
        action.setCallback(this,function(response){
            if(response.getState()==='SUCCESS' && response.getReturnValue()){
                var communityURLlabel = $A.get("$Label.c.Community_URL");
                var redirectLinkForBulkRegistartion=communityURLlabel+"/s/bulk-registration?courseruncode="+code;
                window.open(redirectLinkForBulkRegistartion,"_self");
            }
        });
        $A.enqueueAction(action);
    },
    
    
    ShowToastEvent: function(component, event,Message,title,type){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : title,
            message: Message,
            duration:' 50000',
            // key: 'info_alt',
            type: type,
            // mode: 'pester'
        });
        toastEvent.fire();
    },
    //2021-04-23 Poon Koon: Get Marketing Channels
    /*getMarketingChannels:function(component,event){
        var action =component.get("c.getMarketingChannels");
        action.setCallback(this,function(response){
            if(response.getState()==='SUCCESS' && response.getReturnValue()){
                //console.log(' getMarketingChannels response.getReturnValue() >> ' + JSON.stringify(response.getReturnValue()));
                component.set("v.marketingchanneloptions" , response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },*/
    showDuplicateFunError:function(component,event){
        // give error when More Than Two  Funding Are Added
        var fundingList  = component.get("v.fundingList", fundingList);
        var valueArr = fundingList.map(function(item){ return item.Funding__c });
        var isDuplicate = valueArr.some(function(item, idx) { 
            return valueArr.indexOf(item) != idx 
        });
        console.log(isDuplicate + 'isduplicate==');
        if(isDuplicate == true) {
            var fundingList  = component.get("v.fundingList", fundingList);
            var valueArr = fundingList.map(function(item){ return item.Funding__c });
            var isDuplicate = valueArr.some(function(item, idx) { 
                if( valueArr.indexOf(item) != idx){
                    fundingList.splice(idx, 1); 
                }
                console.log('fun '+idx);
                component.set("v.fundingList", fundingList);
                return valueArr.indexOf(item) != idx; 
            });
            component.set("v.duplicateFundingRecord", true);
            component.set("v.InvalidFundingModalOpen", true);   
        }
    }
    
    // Added By Pradyumn To generate Invoice When SFC Funding Added
    /*   generateInvoiceForSFCFunding: function(component, event) {
         console.log('generateInvoiceForSFCFunding Called');
        var regId = component.get("v.courseRegistrationId");        
        var getinvoice = component.get('c.returnInvoice');
        getinvoice.setParams({courseRegId: regId});
        getinvoice.setCallback(this, function(response) { 
            if(response.getState() === "SUCCESS") {
                console.log('success');
                
                var invoiceId = response.getReturnValue(); 
                component.set("v.invoiceId" , invoiceId);  
                //component.set("v.selTabId" , 'Payment');   
             
            } else if(response.getState() == "ERROR"){
                var errors = response.getError();    
                console.log(errors[0].message);
            }
            
        }); 
        $A.enqueueAction(getinvoice);   
         
    }*/
    
    
    
})