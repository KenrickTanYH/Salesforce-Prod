({
    onInit : function(component, event, helper) {
        
        // Added By Pradyumn to Get value From SFCCallback 
        var vfHost = window.location.href.split('/')[0]+'//'+window.location.href.split('/')[2];
        window.addEventListener("message", $A.getCallback(function(event) {
            if (event.data.statusCode!=='200'){
                //console.log('Code!==200');
                component.set("v.spinner", false);
                component.get("v.popupWin").close();
                setTimeout(function(){
                    component.set("v.ErrorId",event.data.errorId);
                    component.set("v.ErrorMsg",event.data.message);
                    component.set("v.SFCFundingError",true);
                    
                }, 300);
                return;
            }
            // Handle the Data
            // console.log(event.data.Amount+'claimId '+event.data.claimId+' ');
            
            var fullFee = 0;
            var Amount = 0;
            var skillFutureRemainingFee = 0;
            var fundingList = component.get("v.fundingList");
            
            if(component.get("v.courseRunRecord.CourseRecordType__c") == 'Funded_Course'){
                fullFee = component.get("v.courseRunRecord.Course__r.Full_Fee_with_GST__c");
                Amount = event.data.Amount;
                if(fundingList.length>0){
                    for(const fun of fundingList){
                        skillFutureRemainingFee = fun.RemainingFee -Amount ;   
                    }  
                }else{
                    skillFutureRemainingFee = fullFee-Amount;  
                }   
            }
            if(component.get("v.courseRunRecord.CourseRecordType__c") == 'Course'){
                if(component.get("v.memberCheckbox")){
                    fullFee = component.get("v.courseRunRecord.Course__r.Member_Total_Fee__c");
                    Amount = event.data.Amount;
                    if(fundingList.length>0){
                        for(const fun of fundingList){
                            skillFutureRemainingFee = fun.RemainingFee - Amount ; 
                        }  
                    }else{
                        skillFutureRemainingFee = fullFee-Amount;  
                    }   
                }
                else{
                    fullFee = component.get("v.courseRunRecord.Course__r.Non_Member_Total_Fee__c");
                    Amount = event.data.Amount;
                    if(fundingList.length>0){
                        for(const fun of fundingList){
                            skillFutureRemainingFee = fun.RemainingFee - Amount ; 
                        }  
                    }else{
                        skillFutureRemainingFee = fullFee-Amount;  
                    }       
                } 
            }
            //component.set("v.skillFutureRemainingFee", skillFutureRemainingFee.toFixed(2)); 
            
            var fundingList = component.get("v.fundingList");
            fundingList.push({
                'sobjectType': 'Learner_Funding__c',
                'Funding__c': 'SkillsFuture Credit',
                'SFC_Claim_Id__c': event.data.claimId,
                'Amount__c': event.data.Amount,
                'Status__c': 'Confirmed',
                'RemainingFee':skillFutureRemainingFee.toFixed(2),
                'NricId':component.get("v.NricId")
                
            });
            //console.log("fundingList@@@@@@@   "+fundingList);
            component.set("v.fundingList", fundingList);
            component.set("v.skillFutureCreditAdded", true);            
            
            //component.set("v.isSpinner", false); 
            //component.find("isSkillbtn").set("v.disabled", false);
            //component.set("v.openRedirectPopUp",false);
            // Error for Duplicate Funding 
            helper.showDuplicateFunError(component, event);
            component.set("v.spinner", false);
            component.get("v.popupWin").close();
            
        }), false);
        
        
        var courseRegId = window.location.href.split('/')[5];
        component.set("v.courseRegistrationId",courseRegId);
        //console.log('crCodecrCodecrCodecrCode@@ '+cregCode);
        //console.log('courseRegistrationId@@ '+ component.get("v.courseRegistrationId"));
        
        //get course registration values
        var courseRegVal  = component.get("c.getCourseRegValues");
        courseRegVal.setParams({cRegId:courseRegId});
        courseRegVal.setCallback(this, function(response) { 
            console.log('courseRegVal');            
            if(response.getState() === "SUCCESS") {
                console.log('courseRegVal Success'); 
                var courseRegFields = response.getReturnValue();
                component.set("v.memberCheckbox",courseRegFields.IsMember__c);
                component.set("v.NricId",courseRegFields.NRIC__c);
                component.set("v.NricTypeId",courseRegFields.NRIC_Type__c);
                component.set("v.DateOfBirth",courseRegFields.Date_of_Birth__c);
                component.set("v.emailId",courseRegFields.Email_Address__c);
                component.set("v.MobileNo",courseRegFields.Mobile_No__c);
                component.set("v.RegistrationStatus",courseRegFields.Registration_Status__c);
                
                //console.log('crCodecrCodecrCode @@@'+courseRegFields.NRIC__c);
                
            }
        });
        $A.enqueueAction(courseRegVal); 
        
        // console.log('courseRegId '+courseRegId);
        
        //get course run values
        var getCourseRunRecord = component.get('c.getCourseRunRecord');
        getCourseRunRecord.setParams({courseRegId: courseRegId});
        getCourseRunRecord.setCallback(this, function(response) {             
            if(response.getState() === "SUCCESS") {
                component.set("v.courseRunRecord", response.getReturnValue());
                var courseRunRec = response.getReturnValue();
                var fundingVal = component.get("v.courseRunRecord.Course__r.Funding__c");
                //console.log('courseRunRecordfunding @@@'+component.get("v.courseRunRecord.Course__r.Funding__c")+component.get("v.RegistrationStatus")+fundingVal);
                //console.log('typeoffunval '+typeof fundingVal);
                
                component.set("v.quickActionFundingErrorMsg",$A.get("$Label.c.quickActionFundingErrorMsg"))
                if(component.get("v.RegistrationStatus")=='Draft' && fundingVal){
                    component.set("v.isDraft",true);
                    
                }else{
                    component.set("v.isDraftError",true);
                }
                
                // Added by Pradyumn on 29 Nov 2021 to show/Hide the IBF Funding  button
                if(courseRunRec.Course__r.Funding__c.includes('IBF Funding')){
                    component.set("v.IsIbfFunding",true);
                    
                }
                // Added by Pradyumn on 29 Nov 2021 to show/Hide the SkillsFuture Credit  button
                if(courseRunRec.Course__r.Funding__c.includes('SkillsFuture Credit') && courseRunRec.Course__r.SSG_Course_Reference_Number__c != null ){
                    component.set("v.IsSkillFutureCredit",true);
                    
                }
                // Added to show/Hide the check  button
                if(courseRunRec.CourseRecordType__c=='Funded_Course' && courseRunRec.Course__r.Funding__c.includes('SkillsFuture Funding')){
                    component.set("v.IscheckGrant",true);
                }
                
                if (courseRunRec.Id != null) { 
                    component.set("v.courseRunStartDate",courseRunRec.Start_Date__c);
                    component.set("v.courseId", courseRunRec.Course__c);    
                }
                else {
                    //Course Run Not Found
                    helper.createModal(component, "", "Course is not available. Please contact us via the Help Center", "c.redirectToHelpCenter", false);
                }
            } else if(response.getState() == "ERROR"){
                var errors = response.getError();    
                alert(errors[0].message);
            }
        });
        $A.enqueueAction(getCourseRunRecord);  
        
        //get Leaner funding values for course 
        var action = component.get('c.getCourseRegLearnerFunding');
        action.setParams({courseRegId: courseRegId});
        action.setCallback(this, function(response) {
            if(response.getState() === "SUCCESS"){
                var learnerFunValue = response.getReturnValue();
                var addedFundingList = [];
                var fundingList = [];
                var sumOfFundingAmt = 0;
                var remainingFee = 0;
                var fullFee = 0;
                var count = 0;
                
                if(component.get("v.courseRunRecord.CourseRecordType__c") == 'Funded_Course'){
                    fullFee = component.get("v.courseRunRecord.Course__r.Full_Fee_with_GST__c");
                }
                if(component.get("v.courseRunRecord.CourseRecordType__c") == 'Course'){
                    if(component.get("v.memberCheckbox")){
                        fullFee = component.get("v.courseRunRecord.Course__r.Member_Total_Fee__c");   
                    }
                    else{
                        fullFee = component.get("v.courseRunRecord.Course__r.Non_Member_Total_Fee__c");      
                    } 
                }
                
                //calculating remaining fee localy for funding list quick action pop-up
                for(const funVal of learnerFunValue ){
                    addedFundingList.push(funVal.Funding__c);
                    sumOfFundingAmt+=funVal.Amount__c;
                    if(count==0){
                        remainingFee = fullFee -funVal.Amount__c;
                    }else{
                        remainingFee = remainingFee - funVal.Amount__c;
                    }
                    
                    count++;
                    //  console.log('getlearnerAddFunding '+funVal.Funding__c);
                    if(funVal.Funding__c == 'SkillsFuture Credit'){
                        funVal['SFC_Claim_Id__c'] = funVal.SFC_Claim_Id__c;  
                        //console.log('funVal.SFC_Claim_Id__c '+funVal.SFC_Claim_Id__c);
                    }
                    
                    //console.log('remainingFee--->'+remainingFee);
                    funVal['NricId'] = component.get("v.NricId");
                    funVal['RemainingFee'] = remainingFee.toFixed(2);
                    fundingList.push(funVal);
                }
                //console.log('sumOfFundingAmt '+sumOfFundingAmt);
                //console.log('addedFundingList '+addedFundingList);
                //console.log('fundingList '+fundingList);
                //console.log('fundingList '+fundingList[0].remainFee);
                
                component.set("v.addedFundingList",addedFundingList);
                component.set("v.sumOfFundingAmt",sumOfFundingAmt);
                component.set("v.fundingList",fundingList);
                
                //console.log('component '+ component.get("v.fundingList"));
                
            }  
        });
        $A.enqueueAction(action);
        
    },
    
    
    
    handleOnSave : function(component, event, helper) {
        console.log( 'handleOnSuccess==');
        
        // Checking Valid Funding List Added By Pradyumn 27/12/21
        
        component.set('v.validFundingList',null);
        var fundingList = component.get("v.fundingList");  
        var fundingListExist = false;
        
        //  console.log( 'fundingList.length=='+fundingList.length);
        
        if(fundingList.length > 0) {
            let valueArr = fundingList.map(function(item){ return item.Funding__c });
            let isDuplicate = valueArr.some(function(item, idx) { 
                return valueArr.indexOf(item) != idx 
            });
            
            // checking Duplicate for fundings
            //let addedFundingList = component.get("v.addedFundingList");
            //console.log('addedFundingList '+ addedFundingList);
            
            //let valueArr1 = addedFundingList;
            //isDuplicate = valueArr1.some(r=> valueArr.indexOf(r) >= 0);
            
            console.log(isDuplicate + 'isduplicate==');
            if(isDuplicate == true) {
                component.set("v.duplicateFundingRecord", true);
                component.set("v.InvalidFundingModalOpen", true);   
            } 
            else {
                console.log('Else ---> ');
                var validFundingList = [];
                let isValid = true;
                var courseRecordType = component.get("v.courseRunRecord.CourseRecordType__c");
                var nonMemberFee = component.get("v.courseRunRecord.Course__r.Non_Member_Fee__c");
                var fullFee = component.get("v.courseRunRecord.Course__r.Full_Fee__c");
                var nonMemberTotalFee = component.get("v.courseRunRecord.Course__r.Non_Member_Total_Fee__c");
                var fullTotalFee = component.get("v.courseRunRecord.Course__r.Full_Fee_with_GST__c");
                
                var sumOfAmount = 0
                for (let i = 0; i < fundingList.length; i++) {
                    //Add Specific SFC condition
                    //    console.log('includes  '+component.get("v.addedFundingList").includes(fundingList[i].Funding__c));
                    sumOfAmount += parseInt(fundingList[i].Amount__c);
                    if(!component.get("v.addedFundingList").includes(fundingList[i].Funding__c)){
                        
                        if (fundingList[i].Funding__c == 'SkillsFuture Credit') {
                            if(courseRecordType == "Funded_Course" &&                                    
                               fundingList[i].Amount__c > fullTotalFee) {
                                component.set("v.InvalidAmountFundedCourse", true);
                                component.set("v.InvalidFundingModalOpen", true);                       
                                isValid = false;
                            }  else if(courseRecordType != "Funded_Course" && 
                                       fundingList[i].Amount__c > nonMemberTotalFee) {
                                component.set("v.InvalidAmountFundedCourse", true);
                                component.set("v.InvalidFundingModalOpen", true);                       
                                isValid = false;
                            }
                        }
                        else {
                            if(courseRecordType == "Funded_Course" &&                                    
                               fundingList[i].Amount__c > fullFee) {
                                component.set("v.InvalidAmountFundedCourse", true);
                                component.set("v.InvalidFundingModalOpen", true);                       
                                isValid = false;
                            }  else if(courseRecordType != "Funded_Course" && 
                                       fundingList[i].Amount__c > nonMemberFee) {
                                component.set("v.InvalidAmountFundedCourse", true);
                                component.set("v.InvalidFundingModalOpen", true);                       
                                isValid = false;
                            }
                        }
                        if (fundingList[i].Amount__c === '' || fundingList[i].Funding__c == '') {
                            component.set("v.InvalidFundingRecord", true);
                            component.set("v.InvalidFundingModalOpen", true);                        
                            isValid = false;
                        } else if(fundingList[i].Amount__c <= 0 && 
                                  fundingList[i].Funding__c == 'SkillsFuture Credit') {
                            component.set("v.InvalidAmountRecord", true);
                            component.set("v.InvalidFundingModalOpen", true);                        
                            isValid = false;
                        }
                            else {
                                validFundingList.push(fundingList[i]);
                            }
                    }
                    
                    // console.log('sumOfAmount'+sumOfAmount);
                    
                    // Added By Pradyumn to Check Total Amount cant Be greater from fullTotalFee 16/12/21
                    // console.log('sumOfAmount '+sumOfAmount);
                    component.set("v.sumOfAmount",sumOfAmount);
                    
                    if(courseRecordType == "Funded_Course" &&                                    
                       sumOfAmount > fullTotalFee) {
                        component.set("v.InvalidAmountFundedCourse", true);
                        component.set("v.InvalidFundingModalOpen", true);                       
                        isValid = false;
                    }  else if(courseRecordType != "Funded_Course" && 
                               sumOfAmount > nonMemberTotalFee) {
                        component.set("v.InvalidAmountFundedCourse", true);
                        component.set("v.InvalidFundingModalOpen", true);                       
                        isValid = false;
                    }
                    component.set("v.validFundingList",validFundingList);
                    // console.log('validfunlist '+ component.get("v.validFundingList"));
                    // console.log(validFundingList[0] + 'li==');
                }   
            }
            
        } else {
            fundingListExist = false;
        }
        
        let valueArr = fundingList.map(function(item){ return item.Funding__c });
        let isDuplicate = valueArr.some(function(item, idx) { 
            return valueArr.indexOf(item) != idx 
        });
        
        // checking Duplicate for fundings After Validation 
        
        // let addedFundingList = component.get("v.addedFundingList");
        // console.log('addedFundingList '+ addedFundingList);
        
        //let valueArr1 = addedFundingList;
        //isDuplicate = valueArr1.some(r=> valueArr.indexOf(r) >= 0);
        
        console.log(isDuplicate + 'isduplicate==');
        if(isDuplicate == true) {
            component.set("v.duplicateFundingRecord", true);
            component.set("v.InvalidFundingModalOpen", true);   
        } else{
            
            if(courseRecordType == "Funded_Course" &&                                    
               sumOfAmount > fullTotalFee) {
                component.set("v.InvalidAmountFundedCourse", true);
                component.set("v.InvalidFundingModalOpen", true);                       
                isValid = false;
            }  else if(courseRecordType != "Funded_Course" && 
                       sumOfAmount > nonMemberTotalFee) {
                component.set("v.InvalidAmountFundedCourse", true);
                component.set("v.InvalidFundingModalOpen", true);                       
                isValid = false;
            }else{                
                component.set("v.buttonlabel",'Draft');
                var buttonLabel = component.get("v.buttonlabel");      
                
                console.log('buttonLabel '+buttonLabel);
                if(buttonLabel == 'Draft') {   
                    //console.log('Inside Submit ');
                    //var member = component.get("memberCheckbox");  
                    
                    //console.log('Print '+component.get("v.memberCheckbox"));
                    //console.log('Print '+component.get("v.courseRunRecord.Course__r.Provider__c"));
                    //console.log('Print '+component.get("v.courseRunRecord.CourseRecordType__c"));
                    console.log('Print '+$A.util.isEmpty(component.get("v.validFundingList")));
                    
                    var isMember = component.get("v.memberCheckbox");      
                    var provider = component.get("v.courseRunRecord.Course__r.Provider__c");
                    var courseRecordType = component.get("v.courseRunRecord.CourseRecordType__c");
                    var fundingAvailed = $A.util.isEmpty(component.get("v.validFundingList")) == false;
                    
                    
                    if (courseRecordType == 'Funded_Course') {
                        console.log('Funded Course');
                        helper.createLearnerFunding(component, event); 
                        /* if(fundingAvailed){
                    // Added By Pradyumn to Redirect On Payment If SFC Fund Added
                    if(component.get("v.skillFutureCreditAdded")){
                        //helper.generateInvoiceForSFCFunding(component, event); 
                        //condition Need to be add..only redirect to payment is remaining fee is greater from zero
                        //let fullTotalFee = component.get("v.courseRunRecord.Course__r.Full_Fee_with_GST__c");
                        //let totalAmount = component.get("v.sumOfAmount");
                        //component.set("v.PaymentModalOpenForSfc", true);      
                    }
                } */
                    }
                    else{
                        //  console.log('Course Else');
                        if (!isMember && provider == 'SIM' && fundingAvailed) {
                            
                            helper.createLearnerFunding(component, event);    
                            //helper.generateInvoiceForSFCFunding(component, event); 
                            
                        }
                        else if (provider == 'RMIT' && !fundingAvailed) {
                            //component.set("v.PaymentModalOpen", true);  
                            component.set("v.isExecutiveModalOpen", true);
                        }
                            else {
                                
                                helper.createLearnerFunding(component, event); 
                            }
                    }
                }  
                
            }
        }
    },
    
    /* handleDeclineClick : function(component, event, helper) {   
        var checkVar = component.find("checkbox");
        if (checkVar.get("v.value") == true)  {
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/s/"  
            });
            urlEvent.fire();
        } else {
            component.set("v.declineModalOpen", true);            
        }
        
    },*/
    /*handleAlternativeCheck : function(component, event, helper) {
        component.set("v.alternativeIsOpen",event.getSource().get("v.value") );
    },*/
    handleError: function(component, event) {
        var errors = event.getParams();         
        console.log("response", JSON.stringify(errors));
        component.find('ErrMessage').setError('Undefined error occured');
    },
    
    fundingListEventController: function(component, event, helper) {
        var fundingList = event.getParam("fundingList");
        
        //Set the handler attributes based on event data
        component.set("v.fundingList", fundingList);
        
    },
    
    redirectToHome : function (component, event, helper) {
        var cRegId = component.get("v.courseRegistrationId");
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/s/course-registration/" + cRegId
        });
        urlEvent.fire();
    },
    
    redirectHome : function (component, event, helper) {
        //var cRegId = component.get("v.courseRegistrationId");
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/s/"
        });
        urlEvent.fire();
    },
    /* redirectClose : function (component, event, helper) {
        component.set("v.isDeclareClose",false);
    },  */  
    redirectToHelpCenter : function (component) {
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/s/contactsupport"
        });
        urlEvent.fire();
    },
    redirectToMainHome : function (component, event, helper) {
        var cRegId = component.get("v.courseRegistrationId");
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/s/"  
        });
        urlEvent.fire();
    },
    /* closePDPAModel: function(component, event, helper) {
        component.set("v.acceptPDPAOpen", false);
        component.set("v.selTabId" , 'particulars');
    },*/
    //2021-06-14 Poon Koon: Close confirm no funding modal
    /*closeConfirmNoFundingModal: function(component, event, helper) {
        component.set("v.confirmNoFundingOpen", false);
    },*/
    /*closeDeclineModel: function(component, event, helper) {
        component.set("v.declineModalOpen", false);
    },*/
    closeFundingModel: function(component, event, helper) {      
        var fundingRec = component.get("v.InvalidFundingRecord");
        var amountMsg = component.get("v.InvalidAmountRecord");
        var duplicateRecMsg = component.get("v.duplicateFundingRecord");
        var amountWithFundedCourse = component.get("v.InvalidAmountFundedCourse");
        if(fundingRec == true) {
            component.set("v.InvalidFundingRecord", false);
        }
        if(amountMsg == true) {
            component.set("v.InvalidAmountRecord", false);
        }
        if(duplicateRecMsg == true) {
            component.set("v.duplicateFundingRecord", false);
        } 
        if(amountWithFundedCourse == true){
            component.set("v.InvalidAmountFundedCourse", false);
        }
        component.set("v.InvalidFundingModalOpen", false);
    },
    
    
    checkGrant:function(component, event, helper) {
        
        var checkVal='';
        if(component.get("v.NricId") != null && component.get("v.NricId") !='' && component.get("v.NricId") !='undefined'){
            checkVal+='NricId';
        }else{
            component.set("v.ssgIntegrationModalOpen",true);
            component.set("v.ssgMsg",'Identification Number is Blank');
        }
        if(component.get("v.NricTypeId") != null){
            checkVal+='NricTypeId';
        }else{
            component.set("v.ssgIntegrationModalOpen",true);
            component.set("v.ssgMsg",'Identification Type is Blank');
        }
        if(component.get("v.DateOfBirth") != null){
            checkVal+='dobId';
        }else{
            component.set("v.ssgIntegrationModalOpen",true);
            component.set("v.ssgMsg",'Date Of Birth is Blank');
        }
        var idType='';
        if(component.get("v.NricTypeId") != 'Singapore Citizen/PR'){
            component.set("v.ssgIntegrationModalOpen",true);
            component.set("v.ssgMsg",'Funding is Not Applicable');
        }else{
            idType='NRIC';
        }
        if(component.get("v.IscheckGrant") && checkVal=='NricIdNricTypeIddobId' && idType=='NRIC'){
            var CourseRegistrationListRequest=[];
            var CourseRegistrationRecord = {
                id:component.get("v.NricTypeId"),
                idType: idType, 
                dateOfBirth: component.get("v.DateOfBirth"),
                sponsoringEmployerUen:''
            };
            CourseRegistrationListRequest.push(CourseRegistrationRecord);
            //console.log(CourseRegistrationListRequest);
            var action=component.get("c.checkGrants");
            action.setParams({
                startDate:component.get("v.courseRunRecord").Start_Date__c,
                referenceNumber:component.get("v.courseRunRecord").Course__r.SSG_Course_Reference_Number__c,
                listtrainee:JSON.stringify(CourseRegistrationListRequest)
            });
            action.setCallback(this,function(response){
                if(response.getReturnValue().status =='SUCCESS' && response.getState()=='SUCCESS' && response.getReturnValue() != null){
                    // Added by pradyumn for grant remaining fee
                    var fullFee = 0;
                    var Amount = 0;
                    var grantRemainingFee = 0;
                    var fundingList = component.get("v.fundingList");
                    if(component.get("v.courseRunRecord.CourseRecordType__c") == 'Funded_Course'){
                        fullFee = component.get("v.courseRunRecord.Course__r.Full_Fee_with_GST__c");
                        Amount = response.getReturnValue().totalAMt;
                        if(fundingList.length>0){
                            for(const fun of fundingList){
                                grantRemainingFee = fun.RemainingFee - Amount ;   
                            }  
                        }else{
                            grantRemainingFee = fullFee - Amount;  
                        }   
                    }
                    //fullFee = component.get("v.courseRunRecord.Course__r.Full_Fee_with_GST__c");
                    //Amount = response.getReturnValue().totalAMt;
                    // console.log('response '+ response.getReturnValue().totalAMt)
                    //grantRemainingFee =(fullFee-Amount).toFixed(2); 
                    
                    //component.set("v.grantRemainingFee", grantRemainingFee.toFixed(2));
                    //console.log('grantRemainingFee '+grantRemainingFee);
                    
                    //get the account List from component  
                    var fundingList = component.get("v.fundingList");
                    //Add New Account Record
                    fundingList.push({
                        'sobjectType': 'Learner_Funding__c',
                        'Funding__c': response.getReturnValue().sponsoringEmployerUen,
                        'Amount__c': response.getReturnValue().totalAMt,
                        'Status__c': 'Confirmed',
                        'SSG_Response__c': response.getReturnValue().response,
                        'SSG_Funding_Types__c':response.getReturnValue().SSGFundingTypes,
                        'RemainingFee':grantRemainingFee.toFixed(2)  // Added By Pradyumn For Remainig Fee 13/12/21
                    });
                    // console.log("fundingList@@@@@@@   "+fundingList);
                    component.set("v.fundingList", fundingList);
                    
                    component.set("v.grantFundingAdded", true); // Added by  pradyumn
                    //  console.log('grantFundingAdded '+ component.get("v.grantFundingAdded"));
                    helper.showDuplicateFunError(component, event);
                    
                }else if(response.getReturnValue().message !='' && response.getReturnValue().message !=null){
                    // console.log("else If checkGrants@@@@@@@    828");
                    component.set("v.ssgIntegrationErrorModal",true);
                    component.set("v.ssgErrorMsg",response.getReturnValue().message);
                }else{
                    // console.log("else checkGrants@@@@@@@    831");
                    component.set("v.ssgIntegrationModalOpen",true);
                    component.set("v.ssgMsg",'Funding is Not Applicable');
                }
            });
            $A.enqueueAction(action);   
        }
    },
    
    // Added By Pradyumn 26/11/21
    checkSkillFutureCredit:function(component, event, helper) {
        // console.log('claimRequestObj ');        
        var checkVal='';
        // console.log('claimRequestObj12 ');
        if(component.get("v.NricId") != null && component.get("v.NricId") !='' && component.get("v.NricId") !='undefined'){
            // console.log('claimRequestObj123 ');
            checkVal+='NricId';
        }else{
            component.set("v.sfcIntegrationModalOpen",true);
            component.set("v.sfcMsg",'Identification Number is Blank');
        }
        if(component.get("v.NricTypeId") != null){
            checkVal+='NricTypeId';
        }else{
            component.set("v.sfcIntegrationModalOpen",true);
            component.set("v.sfcMsg",'Identification Type is Blank');
        }
        if(component.get("v.courseRunRecord").Course_Run_Code__c != null){
            checkVal+='CourseRunId';
        }else{
            component.set("v.sfcIntegrationModalOpen",true);
            component.set("v.sfcMsg",'CourseRun Id is Blank');
        }
        
        var idType='';
        if(component.get("v.NricTypeId") != 'Singapore Citizen/PR'){
            component.set("v.sfcIntegrationModalOpen",true);
            component.set("v.sfcMsg",'Funding is Not Applicable');
        }else{
            idType='NRIC';
        }
        // console.log('claimRequestObj2 ');
        if(component.get("v.IsSkillFutureCredit") && checkVal=='NricIdNricTypeIdCourseRunId' && idType=='NRIC'){
            // Creating JSON Claim Request for API to Get Claim Request Data
            // console.log('claimRequestObj3 ');
            var claimRequestObj ={
                claimRequest: {
                    course: "",
                    individual: "",
                    additionalInformation:""
                } 
            }
            //  console.log('IBF RE<'+component.get("v.ibfRemainingFee"));
            // console.log('Grant RE<'+component.get("v.grantRemainingFee"));
            
            var fullFee = 0;
            var feeForClaimReq = 0;
            var fundingList = component.get("v.fundingList");
            var gstCode = component.get("v.courseRunRecord.Course__r.GST_Code__c");	
            var gstMode = component.get("v.courseRunRecord.Course__r.GST_Mode__c");	
            //console.log('GST_Code__c '+gstCode);
            //console.log('GST_Code__c '+gstMode);
            
            // Gst Percent Calculation Added By Pradyumn 24/12/21
            let index = gstCode.indexOf("%"); 
            var gstPercent = gstCode.substr(0, index);
            var gstCodePerc = gstPercent/100;
            
            //  console.log('CourseRecordType__c '+component.get("v.courseRunRecord.CourseRecordType__c"));                
            if(component.get("v.courseRunRecord.CourseRecordType__c") == 'Funded_Course'){
                fullFee = component.get("v.courseRunRecord.Course__r.Full_Fee__c");
                // console.log('Full_Fee__c '+fullFee);
                if(fundingList.length>0){
                    for(const fun of fundingList){
                        
                        let gstFreeClaimFee = Math.ceil(fun.RemainingFee / (1 + gstCodePerc));
                        feeForClaimReq = gstFreeClaimFee; 
                    }  
                }else{
                    feeForClaimReq = fullFee;  
                }   
            }
            if(component.get("v.courseRunRecord.CourseRecordType__c") == 'Course'){
                if(component.get("v.memberCheckbox")){
                    fullFee = component.get("v.courseRunRecord.Course__r.Member_Fee__c");
                    if(fundingList.length>0){
                        for(const fun of fundingList){
                            //console.log('gstCode+100%100 '+gstCode+100/100)
                            let gstFreeClaimFee = Math.ceil(fun.RemainingFee / (1 + gstCodePerc));
                            feeForClaimReq = gstFreeClaimFee; 
                        }  
                    }else{
                        feeForClaimReq = fullFee;  
                    }   
                }
                else{
                    fullFee = component.get("v.courseRunRecord.Course__r.Non_Member_Fee__c");
                    if(fundingList.length>0){
                        for(const fun of fundingList){
                            let gstFreeClaimFee = Math.ceil(fun.RemainingFee / (1 + gstCodePerc));
                            feeForClaimReq = gstFreeClaimFee; 
                            
                        }  
                    }else{
                        // console.log('else +Non_Member_Fee__c');
                        feeForClaimReq = fullFee;  
                    }       
                } 
            }
            var Course = {
                id:component.get("v.courseRunRecord.Course__r").SSG_Course_Reference_Number__c,
                fee:feeForClaimReq.toString(),
                runId: component.get("v.courseRunRecord").SSG_Course_Run_ID__c,
                startDate: component.get("v.courseRunRecord").Start_Date__c
                
            };
            var individual = {
                nric: component.get("v.NricId"),
                email: component.get("v.emailId"),
                homeNumber: component.get("v.MobileNo"),
                mobileNumber: component.get("v.MobileNo")
                
            };
            // console.log('claimRequestObj Non_Member_Fee__c');
            claimRequestObj.claimRequest.course= Course;
            claimRequestObj.claimRequest.individual= individual;
            
            // Added to Check the Claim Request Fee should be greater >0
            if(parseFloat(claimRequestObj.claimRequest.course.fee) > 0 && claimRequestObj.claimRequest.course.fee !=''){
                // Sending Claim Request Data to VF Page Using Dynamic URL
                var URL = '/apex/SkillFutureCreditRedirect?id='+claimRequestObj.claimRequest.course.id
                +'&fee='+claimRequestObj.claimRequest.course.fee
                +'&runId='+claimRequestObj.claimRequest.course.runId
                +'&startDate='+claimRequestObj.claimRequest.course.startDate
                +'&nric='+claimRequestObj.claimRequest.individual.nric
                +'&email='+claimRequestObj.claimRequest.individual.email
                +'&homeNumber='+claimRequestObj.claimRequest.individual.homeNumber
                +'&mobileNumber='+claimRequestObj.claimRequest.individual.mobileNumber
                +'&additionalInformation='+claimRequestObj.claimRequest.additionalInformation;
                
                //  console.log(URL);
                component.set("v.dynamicUrl", URL);
                
                const reqBody = JSON.stringify(claimRequestObj);
                // console.log(reqBody);
                
                var action=component.get("c.checkSkillFutureCreditController");
                action.setParams({reqBody:reqBody});
                
                action.setCallback(this,function(response){
                    if(response.getState()=='SUCCESS' && response.getReturnValue() != null){
                        //  console.log('URL');
                        //console.log(response.getReturnValue());
                        //event.getSource().set("v.disabled", true);
                        const claimRequest = response.getReturnValue();
                        component.set("v.claimRequest",claimRequest);
                        // console.log('URL');
                        component.set("v.spinner", true);
                        var w = 1475;
                        var h = 675;
                        var left = Number((screen.width/2)-(w/2));
                        var tops = Number((screen.height/2)-(h/2));
                        
                        //window.open("templates/sales/index.php?go=new_sale", '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+tops+', left='+left);
                        // var popupWin = window.open(URL, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=200,left=400,right=400,width=800,height=600,menubar=no,status=no,titlebar=no,toolbar=no");
                        
                        var popupWin = window.open(URL, "_blank", 'toolbar=yes,scrollbars=yes,resizable=yes,status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+tops+', left='+left);
                        
                        //  console.log('popupWin@@@@@@@ '+typeof popupWin);
                        component.set("v.popupWin",popupWin);
                        
                        
                    }else if(response.getReturnValue().message !='' && response.getReturnValue().message !=null){
                        //console.log("In ELSE IF");
                        component.set("v.sfcIntegrationErrorModal",true);
                        component.set("v.sfcErrorMsg",response.getReturnValue().message);
                    }else{
                        //console.log("In ELSE");
                        component.set("v.sfcIntegrationModalOpen",true);
                        component.set("v.sfcMsg",'Funding is Not Applicable');
                    }
                });
                $A.enqueueAction(action);    
            }
            else{
                //  console.log('ELSE SKSILL'+ component.get("v.InvalidSkillFutureCreditAmt") );
                component.set("v.InvalidSkillFutureCreditAmt",true);
            }
        }
        
    },
    
    // Added by Pradyumn to Close SFC Error Modal
    closeSSGModal: function(component, event, helper) {
        component.set("v.ssgIntegrationModalOpen", false);
        component.set("v.ssgIntegrationErrorModal", false);
    },
    
    
    // Added by Pradyumn to Close SFC Error Modal
    closeSFCModal: function(component, event, helper) {
        component.set("v.sfcIntegrationModalOpen", false);
        component.set("v.sfcIntegrationErrorModal", false);
    },
    
    // Added by Pradyumn to Close SFC Amount Error Modal
    closeSkillFutureFundingModel: function(component, event, helper) {
        component.set("v.InvalidSkillFutureCreditAmt", false);
        
    },
    
    // Added by Pradyumn to Close SFC Amount Error Modal
    closeDraftErrormsgModel: function(component, event, helper) {
        component.set("v.isDraft", false);
        
    },
    // Added by Pradyumn to Close SFC Amount Error Modal
    closeSFCFundingErrorModel: function(component, event, helper) {
        component.set("v.SFCFundingError", false);
        
    },
    // Added by Pradyumn to Add Ibf Funding
    addIbfFunding : function(component, event, helper){
        // console.log('IBF FUNDING @@@@@');
        var fullFee = 0;
        var Amount = 0;
        var ibfRemainingFee = 0;
        var fundingList = component.get("v.fundingList");
        //  console.log(component.get("v.fundingList"));
        //  console.log(component.get("v.courseRunRecord.CourseRecordType__c"));
        if(component.get("v.courseRunRecord.CourseRecordType__c") == 'Funded_Course'){
            fullFee = component.get("v.courseRunRecord.Course__r.Full_Fee_with_GST__c");
            Amount = fullFee*$A.get("$Label.c.IBF_Funding")/100;
            if(fundingList.length>0){
                for(const fun of fundingList){
                    ibfRemainingFee = fun.RemainingFee -Amount ;   
                }  
            }else{
                ibfRemainingFee = fullFee-Amount;  
            }   
        }
        if(component.get("v.courseRunRecord.CourseRecordType__c") == 'Course'){
            console.log('Course ');
            
            if(component.get("v.memberCheckbox")){
                // console.log('Course  isMemberValue');
                fullFee = component.get("v.courseRunRecord.Course__r.Member_Total_Fee__c");
                Amount = fullFee*$A.get("$Label.c.IBF_Funding")/100;
                if(fundingList.length>0){
                    for(const fun of fundingList){
                        ibfRemainingFee = fun.RemainingFee -Amount ; 
                    }  
                }else{
                    console.log('Course  ibfRemainingFee');
                    ibfRemainingFee = fullFee-Amount;  
                }   
            }
            else{
                console.log('Else');
                fullFee = component.get("v.courseRunRecord.Course__r.Non_Member_Total_Fee__c");
                Amount = fullFee*$A.get("$Label.c.IBF_Funding")/100;
                if(fundingList.length>0){
                    for(const fun of fundingList){
                        ibfRemainingFee = fun.RemainingFee -Amount ; 
                    }  
                }else{
                    ibfRemainingFee = fullFee-Amount; 
                    // console.log('ibfRemainingFee '+ibfRemainingFee);
                }       
            } 
        }
        //component.set("v.ibfRemainingFee", ibfRemainingFee.toFixed(2)); 
        //  console.log(component.get("v.fundingList"));
        var fundingList = component.get("v.fundingList");
        fundingList.push({
            'sobjectType': 'Learner_Funding__c',
            'Funding__c': 'IBF Funding',
            'Amount__c': Amount.toFixed(2),
            'Status__c': 'Confirmed',
            'RemainingFee':ibfRemainingFee.toFixed(2)
        });
        component.set("v.fundingList", fundingList);
        component.set("v.ibfFundingAdded", true); 
        // console.log(component.get("v.fundingList"));
        // Added to Check Duplicate Funding
        helper.showDuplicateFunError(component, event);
        
    },
    checkGrantValidation:function(component, event, helper) {
        // console.log('fundingList.length');
        var fundingList = component.get("v.fundingList");
        var flnth = fundingList.length;
        for(var i=flnth-1;i>=0;i--){
            console.log(fundingList.length);
            if(fundingList[i].Status__c=='Confirmed' && fundingList[i].Status__c !='undefined'){
                fundingList.splice(i, 1);
                // console.log(fundingList);
            }
        }
        component.set("v.fundingList", fundingList);
    }
    
})