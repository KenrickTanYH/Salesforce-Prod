({
    doInit: function(component, event, helper) {
        
        component.set("v.discountTypeAmt", true);
        
        var todayDate  = new Date().toISOString().split('T')[0];
        //console.log(todayDate);
        component.set("v.todayDate", todayDate);
        
        var action  = component.get('c.getPromoList');
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                component.set("v.promoCodeList", result);
            }
        });
        $A.enqueueAction(action);  
    },
    
    onPicklistChange : function(component, event, helper)
    {
        
        let fieldName = event.getSource().get("v.fieldName") ; 
        //console.log('fieldName--->'+fieldName);
        let newValue =  event.getSource().get("v.value") ; 
        //console.log('newValue--->'+newValue);
        //let currentRecord = component.get("v.currentRecord") ; 
        
        if(fieldName =='Discount_Type__c'){
            if(newValue == "Percent"  )  {  
                
                component.set("v.discountTypePer", true);
                component.set("v.discountTypeAmt", false);
                
            }
            else if(newValue == "Amount"  )  { 
                component.set("v.discountTypePer", false); 
                component.set("v.discountTypeAmt", true);
                
            } else  { 
                
                component.set("v.discountTypeAmt", false);
                component.set("v.discountTypePer", false);
                
            }
            
        }
        
        
    }, 
    
    closeModel: function(component, event, helper) {
        component.set("v.isModalOpen", false);
        var navService = component.find("navService");    
        var pageReference = {
            "type": 'standard__objectPage',         
            "attributes": {              
                "actionName": "home",               
                "objectApiName":"Promo_Code__c"              
            }        
        };
        component.set("v.pageReference", pageReference);
        var pageReference = component.get("v.pageReference");
        navService.navigate(pageReference,true);
    },
    
    handleSubmit: function(component, event, helper) {
        event.preventDefault();
        var promoCodeListForMail = [];
        const numOfPromoCodes = component.get("v.noOfPromoCodes");
        var DiscountPercent;
        var DiscountAmount;
        
        if(component.get("v.discountTypeAmt")){
            var DiscountAmount = component.find("DiscountAmount").get("v.value");   
        }else if(component.get("v.discountTypePer")){
            var DiscountPercent = component.find("DiscountPercent").get("v.value");    
        }
        
        var StartDate = component.find("StartDate").get("v.value");
        var EndDate = component.find("EndDate").get("v.value");
        var todayDate = component.get("v.todayDate");
        
       // console.log('DiscountPercent '+DiscountPercent+'DiscountAmount '+DiscountAmount+'StartDate '+StartDate+'EndDate '+EndDate+'todayDate '+todayDate);
        //console.log(component.get("v.noOfPromoCodes"));
        
        for(let promo=0;promo<numOfPromoCodes;promo++){
            
            const fields = event.getParam('fields');
            //fields.Start_Date__c = component.get("v.todayDate");
            //let r = (Math.random() + 1).toString(36).substring(8);
            function dec2hex (dec) {
                return dec.toString(16).padStart(2, "0");
            }
            function generateId (len) {
                var arr = new Uint8Array((len) / 2);
                window.crypto.getRandomValues(arr);
                return Array.from(arr, dec2hex).join('');
            }
            var firstCode =generateId(4);
            var secCode =generateId(4);
            
            const PROMOCODE = firstCode.toUpperCase()+secCode.toUpperCase();
            
            if(component.get("v.promoCodeList").includes(PROMOCODE)){
                firstCode =generateId(4);
                secCode =generateId(4);
                
                PROMOCODE = firstCode.toUpperCase()+secCode.toUpperCase();
            }
            fields.Name = PROMOCODE;
            //console.log(fields.Id);
            promoCodeListForMail.push(PROMOCODE);
            //console.log(promoCodeListForMail);

            //console.log('DiscountPercent '+DiscountPercent+'DiscountAmount '+DiscountAmount+'StartDate '+StartDate+'EndDate '+EndDate+'todayDate '+todayDate);
            
            if(component.get("v.discountTypeAmt") && StartDate>=todayDate && EndDate>StartDate && DiscountAmount!== null &&  DiscountAmount !== 'undefined' && DiscountAmount!== '' ){
                //console.log('discountTypeAmt');
                component.find('recordEditForm').submit(fields);               
            }
            else if(component.get("v.discountTypePer") && StartDate>=todayDate && EndDate>StartDate && DiscountPercent !==null &&  DiscountPercent !== 'undefined' && DiscountAmount!== ''){
                //console.log('discountTypePer');
                component.find('recordEditForm').submit(fields);  
            }else{
           
                //console.log("Please Fill Required Fields");
                if(component.get("v.discountTypeAmt") && DiscountAmount === null ||  DiscountAmount === 'undefined' || DiscountAmount === ''){
                    
                 helper.showError(component,event,"Please Fill The Discount Amount Field");                    
                }
                if(component.get("v.discountTypePer") && DiscountPercent === null ||  DiscountPercent === 'undefined' || DiscountPercent === ''){
                    
                 helper.showError(component,event,"Please Fill The Discount Percent Field");                    
                }
                if(StartDate<todayDate || EndDate<StartDate){
                    
                  helper.showError(component,event,"Please Fill The Date Field Correctly");  
                    
                }
                
               /* var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": "Please fill the required fields and Date Correctly",
                    "type": "error"
                });
                toastEvent.fire();*/
                
            }
            
            //component.find('recordEditForm').submit(fields);  
            
        }
        component.set("v.promoCodeListForMail",promoCodeListForMail);
        //console.log(component.get("v.promoCodeListForMail"));
        
    },
    
    handleSuccess : function(component,event,helper) {
        
        
        
        if(component.get("v.noOfPromoCodes")>1){
            var navService = component.find("navService");    
            var pageReference = {
                "type": 'standard__objectPage',         
                "attributes": {              
                    "actionName": "home",               
                    "objectApiName":"Promo_Code__c"              
                }        
            };
            
            var record = event.getParams();  
            var resultsToast = $A.get("e.force:showToast");
            resultsToast.setParams({
                "title": "Saved",
                "message": "Unique Promo Code(s) is generated."
            });
            resultsToast.fire();
            
            component.set("v.pageReference", pageReference);
            var pageReference = component.get("v.pageReference");
            navService.navigate(pageReference,true);
            
        }else{
            
            var record = event.getParams();  
            var resultsToast = $A.get("e.force:showToast");
            resultsToast.setParams({
                "title": "Saved",
                "message": "Unique Promo Code(s) is generated."
            });
            resultsToast.fire();
            
            var record = event.getParams().response;
            var navService = component.find("navService");    
            console.log(navService);
            var pageReference = {
                "type": 'standard__recordPage',         
                "attributes": {              
                    "recordId":record.id,
                    "actionName": "view",               
                    "objectApiName":"Promo_Code__c"              
                }        
            };
            
            component.set("v.pageReference", pageReference);
            var pageReference = component.get("v.pageReference");
            navService.navigate(pageReference,true); 
        }
        
        var action  = component.get('c.sendEmail');
        action.setParams({promoCodeListForMail: component.get("v.promoCodeListForMail")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
            }
        });
        $A.enqueueAction(action);
        
    }
    
    /*  onload: function(component, event, helper){
        if(event.getParam("recordUi").record){
            component.set("v.currentRecord", JSON.parse(JSON.stringify(event.getParam("recordUi").record.fields)));
        }
    }*/
    
    
})