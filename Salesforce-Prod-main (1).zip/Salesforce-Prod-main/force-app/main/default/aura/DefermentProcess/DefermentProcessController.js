({
	doInit : function(component, event, helper) {
        helper.PickListPenaltyType(component,event);
        helper.getCourseRecordALL(component, event);
        helper.getCourseRegisterationAll(component,event);
	},
    checkValidation:function(component, event, helper) {
        if(!component.get("v.SIMInitiated")){
            var index=event.getSource().get("v.accesskey");
            var dateOfCourseRun=component.get("v.courseRegistrationList")[index].CourseRunIdStartDate;
            var action= component.get("c.checkDaysBetween");
            action.setParams({
                courseRunDate:dateOfCourseRun,
                requestedDate:event.getSource().get("v.value")
            });
            action.setCallback(this,function(response){
                if(response.getState()=='SUCCESS'){
                    var courseRegistrationListNew = component.get("v.courseRegistrationList");
                    //var newlst =[];
                    console.log(courseRegistrationListNew[index].isPaid);
                    if(courseRegistrationListNew[index].isPaid){
                        courseRegistrationListNew[index].Disabled=response.getReturnValue();
                        if(!response.getReturnValue()){
                            courseRegistrationListNew[index].Required=true;
                            courseRegistrationListNew[index].penaltyApplicable=true;
                            courseRegistrationListNew[index].penaltyApplicableDisable=false;
                        }else{
                            courseRegistrationListNew[index].Type='Amount';
                            courseRegistrationListNew[index].penaltyVal=null;
                            courseRegistrationListNew[index].Required=false; 
                            courseRegistrationListNew[index].penaltyApplicable=false;
                            courseRegistrationListNew[index].penaltyApplicableDisable=true;
                        }   
                    }
                    component.set("v.courseRegistrationList",courseRegistrationListNew);
                   /* for(var i=0; i<courseRegistrationListNew.length;i++){
                        console.log(courseRegistrationListNew[index].isPaid);
                        if(courseRegistrationListNew[index].isPaid){
                            courseRegistrationListNew[index].Disabled=response.getReturnValue();
                            if(!response.getReturnValue()){
                                courseRegistrationListNew[index].Required=true;
                                courseRegistrationListNew[index].penaltyApplicable=true;
                                courseRegistrationListNew[index].penaltyApplicableDisable=false;
                            }else{
                                courseRegistrationListNew[index].Required=false; 
                                courseRegistrationListNew[index].penaltyApplicable=false;
                                courseRegistrationListNew[index].penaltyApplicableDisable=true;
                            }   
                        }
                        newlst.push(courseRegistrationListNew[i]);
                    }
                    component.set("v.courseRegistrationList",newlst);*/
                }else if (response.getState() === "ERROR"){
                    console.log(response.getState()+'Error--->>>'+ response.getError());
                }
            });
            $A.enqueueAction(action);
        }
    },
    checkPenalty:function(component, event, helper){
        if(!component.get("v.SIMInitiated")){
            var index=event.getSource().get("v.accesskey");
            var courseRegistrationListNew = component.get("v.courseRegistrationList");
            var newlst =[];
            for(var i=0; i<courseRegistrationListNew.length;i++){
                if(event.getSource().get("v.checked")){
                    courseRegistrationListNew[index].Disabled=false;
                    courseRegistrationListNew[index].Required=true;
                }else{
                    courseRegistrationListNew[index].Type='Amount';
                    courseRegistrationListNew[index].penaltyVal=null;
                    courseRegistrationListNew[index].Disabled=true;
                    courseRegistrationListNew[index].Required=false;
                }
                newlst.push(courseRegistrationListNew[i]);
            }
            component.set("v.courseRegistrationList",newlst);   
        }
    },
    checkStatus:function(component, event, helper){
        var index=event.getSource().get("v.accesskey");
        var courseRegistrationListNew = component.get("v.courseRegistrationList");
        var newlst =[];
        for(var i=0; i<courseRegistrationListNew.length;i++){
            if(event.getSource().get("v.value")=='Deferment'){
                courseRegistrationListNew[index].requiredNewCourse=true;
            }else{
                courseRegistrationListNew[index].requiredNewCourse=false;
            }
            newlst.push(courseRegistrationListNew[i]);
        }
        component.set("v.courseRegistrationList",newlst);
    },
    saveClick:function(component, event, helper){
        var courseRegistrationListNew = component.get("v.courseRegistrationListSelect");
        if(courseRegistrationListNew.length >0){
            var newlst =[];
            var errorVal=false;
            for(var i=0; i<courseRegistrationListNew.length;i++){
                if(courseRegistrationListNew[i].newCourseRun == null && courseRegistrationListNew[i].Status=='Deferment'){
                    errorVal=true;
                }
            }
            if(errorVal){
                component.set("v.isError",true);
                component.set("v.errorMsg",'Please Select New Course Run');   
            }else{
                helper.saveRecord(component, event);   
            }   
        }else{
            component.set("v.isError",true);
            component.set("v.errorMsg",'Please Select Atleast 1 course registration');
        }
    },
    disablePenaltyApplicable:function(component, event, helper){
        var courseRegistrationListNew = component.get("v.courseRegistrationList");
        var newlst =[];
        if(component.get("v.SIMInitiated")){
            for(var i=0; i<courseRegistrationListNew.length;i++){
                courseRegistrationListNew[i].simInitiated=true;
                courseRegistrationListNew[i].Type='Amount';
                courseRegistrationListNew[i].penaltyVal=null;
                courseRegistrationListNew[i].RequestedDate=null;
                courseRegistrationListNew[i].Disabled=true;
                courseRegistrationListNew[i].Required=false;
                courseRegistrationListNew[i].penaltyApplicable=false;
                courseRegistrationListNew[i].penaltyApplicableDisable=true;
                newlst.push(courseRegistrationListNew[i]);
            }
            component.set("v.courseRegistrationList",newlst);   
            //component.set("v.penaltyApplicableDisable",true);
            component.set("v.disabledRequestedDate",true);
        }else{
            for(var i=0; i<courseRegistrationListNew.length;i++){
                courseRegistrationListNew[i].simInitiated=false;
                courseRegistrationListNew[i].penaltyApplicableDisable=true;
                newlst.push(courseRegistrationListNew[i]);
            }
            component.set("v.courseRegistrationList",newlst); 
         	 //component.set("v.penaltyApplicableDisable",false);
            component.set("v.disabledRequestedDate",false);
        }
    },
    selectRecord:function(component, event, helper){
        var index=event.getSource().get("v.accesskey");
        var courseRegistrationListNew = component.get("v.courseRegistrationList");
        var newlst =component.get("v.courseRegistrationListSelect");
        if(event.getSource().get("v.checked")){
            if(courseRegistrationListNew[index].noOfDeferment > $A.get("$Label.c.Total_Deferment_Count") && !courseRegistrationListNew[index].simInitiated){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "warning",
                    "message": "Learner has already deferred for " +$A.get("$Label.c.Total_Deferment_Count") + " or more times."
                });
                toastEvent.fire();
            }
         	newlst.push(courseRegistrationListNew[index]); 
        }else{
            var Ids=courseRegistrationListNew[index].courseRegisterId;
            for(var i=0;i<=newlst.length;i++){
                if(newlst[i].courseRegisterId==Ids){
                    newlst.splice(i, 1);
                    break;
                }
            }
        }
        component.set("v.courseRegistrationListSelect",newlst);
        console.log(component.get("v.courseRegistrationListSelect"));
    },
    closeModel: function(component, event, helper) {
      // for Hide/Close Model,set the "isOpen" attribute to "Fasle" 
        if(component.get("v.successMsg")=='The Record has been Successfuly Processed'){
            var workspaceAPI = component.find("DeferrmentScreen");
            workspaceAPI.getFocusedTabInfo().then(function(response) {
                var focusedTabId = response.tabId;
                workspaceAPI.closeTab({tabId: focusedTabId});
            })
            .catch(function(error) {
                console.log(error);
            });
            window.open("/"+component.get("v.recordId"),"_self");
        } 
        component.set("v.isOpen", false);
        component.set("v.isError",false);
   },
    cancelClick : function(component, event, helper) {
        var workspaceAPI = component.find("DeferrmentScreen");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            console.log(error);
        });
    }
    
})