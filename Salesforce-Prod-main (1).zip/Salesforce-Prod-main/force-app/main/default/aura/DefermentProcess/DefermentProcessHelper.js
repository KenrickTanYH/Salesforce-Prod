({
	getCourseRecordALL : function(component,event) {
		var action= component.get("c.getCourseRecord");
        action.setParams({
            'recordId':component.get("v.recordId") 
        });
        action.setCallback(this,function(response){
            if(response.getState()=='SUCCESS'){
                component.set("v.courseRec",response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
	},
    getCourseRegisterationAll:function(component,event){
        var action= component.get("c.getCourseRegistrationRecord");
        action.setParams({
            'recordId':component.get("v.recordId") 
        });
        action.setCallback(this,function(response){
            if(response.getState()=='SUCCESS'){
                component.set("v.courseRegistrationList",response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    saveRecord:function(component,event){
        component.set("v.showSpinner",true);
        var action= component.get("c.saveRecordList");
        action.setParams({
            'courseRegistrationList':JSON.stringify(component.get("v.courseRegistrationListSelect")) 
        });
        action.setCallback(this,function(response){
            if(response.getState()=='SUCCESS' && response.getReturnValue()=='SUCCESS'){
                component.set("v.showSpinner",false);
                component.set("v.courseRegistrationListSelect",[]);
                component.set("v.isOpen", true);
                component.set("v.successMsg", 'The Record has been Successfuly Processed');
               // component.set("v.courseRegistrationList",response.getReturnValue());
            }else{
                component.set("v.isOpen", true);
                component.set("v.successMsg", 'Please Contact System Admin');
                component.set("v.showSpinner",false);
                console.log(response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    PickListPenaltyType: function(component, event) {
        var action = component.get("c.PickListPenaltyTypeValue");
        action.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS') {
                if(response.getReturnValue() != null) {
                    component.set("v.penaltypicklist",response.getReturnValue());
                }
            }	    
        });
        $A.enqueueAction(action);
	}
})