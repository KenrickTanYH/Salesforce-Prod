({
    doInit : function(component, event, helper) {
        var action = component.get("c.fetchSessionDateRecordIds");  
        action.setParams({
            "aRecordId": component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
                component.set('v.SessionIdList', response.getReturnValue());   
                component.set('v.loaded', true);
                if(response.getReturnValue().length == 0){
                    component.set("v.isOpen", true); 
                } 
            }else{
                this.showToast(component, event, 'fail'); 
            }
        }); 
        $A.enqueueAction(action);
    },
    
    addDates : function(component, event, helper) {
        component.set("v.AddDates", true);
        component.set("v.isOpen", true);
    },
    removeRow: function(component, event, helper) {        
        var jdList = component.get("v.SessionIdList");
        var selectedItem = event.currentTarget;
        var index = selectedItem.dataset.record;        
        var deleteList = component.get("v.DeletedIdList");
        deleteList.push(jdList[index]);
        component.set("v.DeletedIdList",deleteList);
        jdList.splice(index, 1);
        component.set("v.SessionIdList", jdList);
         if(jdList.length == 0){
            component.set("v.isOpen", false);
        }
    },
    
    cancel: function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
    },
    
    save : function(component, event, helper){   
         component.set('v.loaded', false);
        var action = component.get("c.deleteSessionDates");  
        action.setParams({
            "eSessionDateIds": component.get("v.DeletedIdList")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "Dates updated successfully",
                    "type" : "success"
                });
                toastEvent.fire();      
                $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire(); 
            }else{
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": "Please contact your System Admin",
                    "type" : "error"
                });
                toastEvent.fire();  
            }
        }); 
        
        $A.enqueueAction(action);
        
        component.find("editForm").forEach( form =>{
            form.submit();
        })            
        },
            
        })