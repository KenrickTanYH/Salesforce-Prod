({
	 showToast: function(component, event, status){
        if(status == 'pass'){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Success!",
                "message": "Dates added/updated successfully",
                "type" : "success"
            });
            toastEvent.fire(); 
            $A.get("e.force:closeQuickAction").fire();
        }else{
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": "Please contact your System Admin",
                "type" : "error"
            });
            toastEvent.fire();  
        }
    }
})