({
    doInit: function(component, event, helper) {
        console.log("controller recordId -> "+ component.get("v.recordId"));
        helper.getConsolidatedInvoice(component,event);
    },
    doConsolidateRecords: function(component, event, helper) {
        var allRecords = component.get("v.ConsolidatedInvoice");
        var selectedRecords = [];
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].isChecked) {
                console.log('invoiceId --> '+allRecords[i].invId)
                var selectedArray = {
                    CourRegId:allRecords[i].recid,
                    InvoiceId: allRecords[i].invId
                }
                selectedRecords.push(selectedArray);
            }
        }
        console.log('selectedRecords length --> '+selectedRecords.length)
        if(!$A.util.isEmpty(selectedRecords))
            if(selectedRecords.length>=2){
                helper.createConsolidatedInvoice(component,event,selectedRecords);
            }
            else{
                helper.showToastEvent(component, event,$A.get("$Label.c.ConsolidatedRecordWarning"),'warning','warning');
            }
    },
    doCancel: function(component, event, helper) {
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": component.get("v.recordId"),
            "slideDevName": "related"
        });
        navEvt.fire();
    },
    openRecord : function (component, event, helper) {
        var selectedItem = event.currentTarget;
        console.log('course reg id -- > '+ selectedItem.getAttribute("Data-recordid"));
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": selectedItem.getAttribute("Data-recordid"),
            "slideDevName": "related"
        });
        navEvt.fire();
    }
})