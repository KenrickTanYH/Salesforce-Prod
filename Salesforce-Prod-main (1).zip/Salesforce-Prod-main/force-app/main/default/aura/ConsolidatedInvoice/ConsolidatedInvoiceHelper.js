({
    getConsolidatedInvoice : function(component,event) {
        console.log("Helper recordId -> "+ component.get("v.recordId"));
        var getConsolidatedInvoice = component.get('c.getConsolidatedInvoice');
        getConsolidatedInvoice.setParams({sRecordId: component.get("v.recordId")});
        getConsolidatedInvoice.setCallback(this, function(response) {
            console.log('getState --> '+response.getState())
            if(response.getState() === "SUCCESS") {
                console.log('getConsolidatedInvoice --> '+JSON.stringify(response.getReturnValue()));
                if(!$A.util.isEmpty(response.getReturnValue())){
                    component.set("v.ConsolidatedInvoice",response.getReturnValue());
                }  
            }
            else if (response.getState() === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                        this.showToastEvent(component, event,"Error occured! Please contact the system admin.",'Error','error');
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(getConsolidatedInvoice); 
    },
    showToastEvent: function(component, event,Message,title,type){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : title,
            message: Message,
            duration:' 2000',
            key: 'info_alt',
            type: type
        });
        toastEvent.fire();
    },
    createConsolidatedInvoice : function(component,event,selectedRecords) {
        component.set("v.Spinner", true); 
        var createConsolidatedInvoice = component.get('c.getConsolidatedInvoiceList');
        createConsolidatedInvoice.setParams({listWrapperConsldatedInvoice: selectedRecords});
        createConsolidatedInvoice.setCallback(this, function(response) {
            console.log('getState --> '+response.getState())
            if(response.getState() === "SUCCESS") {
                console.log('invoice id  --> '+JSON.stringify(response.getReturnValue()));
                if(!$A.util.isEmpty(response.getReturnValue())){
                    component.set("v.Spinner", false); 
                    $A.get('e.force:refreshView').fire();
                    
                    this.showToastEvent(component, event,$A.get("$Label.c.ConsolidatedRecordProcess"),'Success','success'); 
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId": response.getReturnValue(),
                        "slideDevName": "related"
                    });
                    navEvt.fire();
                }  
            }
            else if (response.getState() === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                        // alert("Error --> "+errors[0].message);
                        this.showToastEvent(component, event,"Error occured! Please contact the system admin.",'Error','error');
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(createConsolidatedInvoice);
    }
})