({
    onInit: function(component, event, helper) {
        // console.log('TESTFEE'+component.get("v.ibfRemainingFee"));
        var inputsel = component.find("InputSelectDynamic");
        var courseIdVar = component.get('v.courseId');
        var opts=[];
        var action = component.get('c.getLearnerFundingValues');
        action.setParams({courseId: courseIdVar});
        action.setCallback(this, function(response) { 
            if(response.getState() === "SUCCESS") {
                var optionList = response.getReturnValue().filter(fund => fund !== 'SkillsFuture Credit');  //  SkillsFuture Credit filtred from picklist Added By pradyumn 9 Dec 2021
                component.set("v.options", optionList);
            } else if(response.getState() == "ERROR"){
                var errors = response.getError();    
                console.log(errors[0].message);
            }
        }); 
        $A.enqueueAction(action); 
        // helper.addFundingRecord(component, event);
    },
    addRow: function(component, event, helper) {
        if (helper.validateFundingList(component, event)) {
            helper.addFundingRecord(component, event);
        } 
    },
    
    removeRow: function(component, event, helper) {
        //Get the account list
        var fundingList = component.get("v.fundingList");
        //Get the target object
        var selectedItem = event.currentTarget;
        //Get the selected item index
        var index = parseInt(selectedItem.dataset.record);
        //set the var for full fee
        var fullFee = 0;
        
        var regId = component.get("v.courseRegistrationId");
        // console.log('courseRegistrationId '+regId);
        // console.log('Funding__c '+fundingList[index].Funding__c);
        
        // calculating Full Fee According To Type Of Course Added By Pradyumn 
        if(component.get("v.courseRunRecord.CourseRecordType__c") == 'Funded_Course'){
            fullFee = component.get("v.courseRunRecord.Course__r.Full_Fee_with_GST__c");
        }else{
            //  console.log('isMemberValue'+component.get("v.isMemberValue"));
            if(component.get("v.isMemberValue")){
                fullFee = component.get("v.courseRunRecord.Course__r.Member_Total_Fee__c");    
            }
            else{
                fullFee = component.get("v.courseRunRecord.Course__r.Non_Member_Total_Fee__c");
            }  
        }
        
        //remove Ibf Funding Added by pradyumn
        if(fundingList[index].Funding__c=='IBF Funding'){
            if(fundingList.length>1 ){
                var allRemainFee = 0
                for(const fun of fundingList){
                    if(allRemainFee==0 && fun.Funding__c!='IBF Funding'){
                        fun.RemainingFee = (fullFee - fun.Amount__c).toFixed(2); 
                        allRemainFee = fullFee - fun.Amount__c;  
                    }
                    else if(allRemainFee!=0 && fun.Funding__c!='IBF Funding'){
                        fun.RemainingFee = (allRemainFee - fun.Amount__c).toFixed(2);
                        allRemainFee = allRemainFee - fun.Amount__c;
                    } 
                }
            }else{
                fundingList[index].RemainingFee=0; 
            }
            fundingList[index].RemainingFee=0;
            component.set("v.ibfFundingAdded", false);
            //component.set("v.ibfRemainingFee", 0);
            helper.deleteLearnerFunding(component,regId,"IBF Funding");
        }
        //remove Grant Funding Added by pradyumn
        if(fundingList[index].Funding__c=='SkillsFuture Funding'){
            if(fundingList.length>1 ){
                var allRemainFee = 0
                for(const fun of fundingList){
                    if(allRemainFee==0 && fun.Funding__c!='SkillsFuture Funding'){
                        fun.RemainingFee = (fullFee - fun.Amount__c).toFixed(2); 
                        allRemainFee = fullFee - fun.Amount__c;  
                    }
                    else if(allRemainFee!=0 && fun.Funding__c!='SkillsFuture Funding'){
                        fun.RemainingFee = (allRemainFee - fun.Amount__c).toFixed(2); 
                        allRemainFee = allRemainFee - fun.Amount__c; 
                    } 
                }
            }else{
                fundingList[index].RemainingFee=0; 
            }
            fundingList[index].RemainingFee=0;
            component.set("v.grantFundingAdded", false);
            //console.log('before deleteLearnerFunding');
            helper.deleteLearnerFunding(component,regId,"SkillsFuture Funding");
            //component.set("v.grantRemainingFee", 0);
        }
        
        //remove Skill Future Funding Added by pradyumn
        if(fundingList[index].Funding__c=='SkillsFuture Credit'){
            if(fundingList.length>1 ){
                var allRemainFee = 0
                for(const fun of fundingList){
                    if(allRemainFee==0 && fun.Funding__c!='SkillsFuture Credit'){
                        fun.RemainingFee = (fullFee - fun.Amount__c).toFixed(2); 
                        allRemainFee = fullFee - fun.Amount__c;  
                    }
                    else if(allRemainFee!=0 && fun.Funding__c!='SkillsFuture Credit'){
                        fun.RemainingFee = (allRemainFee - fun.Amount__c).toFixed(2); 
                        allRemainFee = allRemainFee - fun.Amount__c; 
                    } 
                }
            }else{
                fundingList[index].RemainingFee=0; 
            }
            fundingList[index].RemainingFee=0;
            component.set("v.skillFutureCreditAdded", false);
            //component.set("v.skillFutureRemainingFee", 0);
            //Need To add Cancel SFC Claim
            let claimId = fundingList[index].SFC_Claim_Id__c;
            let nric = fundingList[index].NricId;
            
            //  console.log('claimId '+claimId+ ' '+nric);
            helper.cancelSFCClaim(component,claimId,51,nric);
            helper.deleteLearnerFunding(component,regId,"SkillsFuture Credit");
        }
        
        fundingList.splice(index, 1);
        console.log('fun '+index);
        component.set("v.fundingList", fundingList);
        var cmpEvent = component.getEvent("FundingListEvent"); 
        //Set event attribute value
        cmpEvent.setParams({"fundingList" : component.get('v.fundingList')}); 
        
        
        cmpEvent.fire(); 
    },
    
    save: function(component, event, helper) {
        alert(JSON.stringify(component.get('v.fundingList')));
        /*
        if (helper.validateFundingList(component, event)) {
            helper.saveAccountList(component, event);
        } */
    },
    sendFundingList: function(component, event, helper) {
        var cmpEvent = component.getEvent("FundingListEvent"); 
        var fundingList = component.get("v.fundingList");
        
        //Auto populate amount to 1 for other fundings 
        for (var i = 0; i < fundingList.length; i++) {
            // MVP 1.1:added by Ravi when status is confirmed it wont change the amount to 0
            if (fundingList[i].Funding__c != 'SkillsFuture Credit' && fundingList[i].Status__c != 'Confirmed') {
                fundingList[i].Amount__c = 0;
            }
        }
        component.set("v.fundingList", fundingList);
        //Set event attribute value
        cmpEvent.setParams({"fundingList" : component.get('v.fundingList')}); 
        cmpEvent.fire(); 
    },
    closeFundingModel: function(component, event, helper) {
        component.set("v.FundingModalOpen", false);
    },
     //2022-02-08 Daksh Mandowara : add event handler for Promocode validation model popup
    closeModelOk: function(component, event, helper) {
      component.set("v.isPromoCodeApplied", false);
    },
    // End chnages by daksh mandowara
})