({
    addFundingRecord: function(component, event) {
         // 2022-02-08 Daksh Mandowara : check condition for promocode is applied or not
        if(component.get("v.PromoCodeApplied")){
            component.set("v.isPromoCodeApplied",true);
            //alert("Please remove promocode before adding learning funding");
        }else{
            
		// End changes by Daksh Mandowara  
        //get the account List from component  
        var fundingList = component.get("v.fundingList");
        //Add New Account Record
        fundingList.push({
            'sobjectType': 'Learner_Funding__c',
            'Funding__c': component.get("v.options")[0],
            'Amount__c': '',
        });
        
        //Auto populate amount to 1 for other fundings 
        for (var i = 0; i < fundingList.length; i++) {
            // MVP 1.1:added by Ravi when status is confirmed it wont change the amount to 1
            if (fundingList[i].Funding__c != 'SkillsFuture Credit' && fundingList[i].Status__c != 'Confirmed') {
                fundingList[i].Amount__c = 1;
            }
        }
        
        component.set("v.fundingList", fundingList);
        var cmpEvent = component.getEvent("FundingListEvent"); 
        //Set event attribute value
        cmpEvent.setParams({"fundingList" : component.get('v.fundingList')}); 
        cmpEvent.fire(); 
        }
    },
    
    validateFundingList: function(component, event) {
        //Validate all account records
        var isValid = true;
        var fundingList = component.get("v.fundingList");
        for (var i = 0; i < fundingList.length; i++) {
            if ((fundingList[i].Funding__c == 'SkillsFuture Credit' 
                 && fundingList[i].Amount__c == '') ||
                fundingList[i].Funding__c == '') {
                isValid = false;
                component.set("v.FundingModalOpen", true);
            }
        }
        return isValid;
    },
    
    deleteLearnerFunding: function(component,regId,fundingName) {
        //console.log('deleteLearnerFunding')
        //console.log('pass val on helper '+regId+' '+ fundingName);
        
        var action = component.get('c.deleteLearnerFunding');
        action.setParams({regId:regId,fundingName:fundingName});
        action.setCallback(this, function(response) {
            if(response.getState() === "SUCCESS") {
                console.log('SUCCESS');
                var result = response.getReturnValue();   
            } 
        });
        $A.enqueueAction(action);
    },
    
    cancelSFCClaim: function(component,claimId,claimCancelCode,nric) {
        //console.log('cancelSFCClaim')
        //console.log('pass val on helper '+claimId+' '+ claimCancelCode+' '+nric);
        
        var action = component.get('c.cancelSFCClaims');
        action.setParams({claimId:claimId,claimCancelCode:claimCancelCode,nric:nric});
        action.setCallback(this, function(response) {
            if(response.getState() === "SUCCESS") {
                console.log('SUCCESS');
                var result = response.getReturnValue();
                //console.log('result '+result);
            } 
        });
        $A.enqueueAction(action);
    }     
    
})