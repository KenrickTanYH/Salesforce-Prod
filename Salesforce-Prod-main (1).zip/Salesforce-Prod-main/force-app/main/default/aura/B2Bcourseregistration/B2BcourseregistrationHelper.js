({
    getJsonFromUrl: function () {
        var query = location.search.substr(1);
        var result = {};
        query.split("&").forEach(function (part) {
            var item = part.split("=");
            result[item[0]] = decodeURIComponent(item[1]);
        });
        return result;z
    }
    ,
    ValidateEmail: function (inputText) {
        //alert('Helper call inputText Email ==> '+inputText)
        let mailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (inputText.match(mailformat))
            return true;
        else
            return false;
    }
    , ValidateMobile: function (inputText) {
        console.log('Helper mobile for only inputText ==> ' + inputText)
        var phoneno = /^\d{10}$/;
        if (inputText.match(phoneno))
            return true;
        else
            return false;
    }
    , ValidateDateOfBirth: function (inputText) {
        var m = inputText.match(/^(\d\d?)\/(\d\d?)\/(\d{4})$/);
        //new Date(m[3], m[2]-1, m[1])
        var myDate = new Date(m[3], m[2] - 1, m[1]); //new Date(inputText);
        // alert('inputText Date --> '+myDate) 
        var today = new Date();
        // alert(today+ '      ValidateDateOfBirth ==>    '+myDate)
        if (myDate > today)
            return false;
        else
            return true;
    },
    ValidateDateformate: function (inputText) {
        const regExp = /^(\d\d?)\/(\d\d?)\/(\d{4})$/;
        let isvalidDate;
        let matches = inputText.match(regExp);
        let isValid = matches;
        let maxDate = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        
        if (matches) {
            /*alert('Date --> '+parseInt(matches[1]));
            alert('month --> '+parseInt(matches[2]));
            alert('year --> '+parseInt(matches[3]));*/
            const date = parseInt(matches[1]);
            const month = parseInt(matches[2]);
            const year = parseInt(matches[3]);
            isValid = month <= 12 && month > 0;
            isValid &= date <= maxDate[month] && date > 0;
            const leapYear = (year % 400 == 0)
            || (year % 4 == 0 && year % 100 != 0);
            isValid &= month != 2 || leapYear || date <= 28;
        }
        if (isValid == 1)
            isvalidDate = true;
        else if (isValid == 0)
            isvalidDate = false;
        
        return isvalidDate;
    }
    , ValidateNricType: function (component, event, nricType, NricNumber, isPopup) {
        
        var nricIsValid = true;
        let nricMap = new Map(Object.entries(component.get("v.mapNRICGrid")));
        var nricMapone = new Map(Object.entries(component.get("v.mapNRICGridF")));
        console.log('103 --> ' + JSON.stringify(component.get("v.mapNRICGrid")));
        console.log('104 --> ' + JSON.stringify(component.get("v.mapNRICGridF")));
        console.log('106 nricType --> ' + nricType);
        console.log('107 NricNumber--> ' + NricNumber);
        
        if ((nricType == 'FIN' || nricType == 'Singapore Citizen/PR')) {
            if (!$A.util.isEmpty(NricNumber)) {
                if (!$A.util.isEmpty(NricNumber) && (nricType == 'FIN' || nricType == 'Singapore Citizen/PR')) {
                    var nricval = NricNumber;
                    console.log('116 nricval.length --> ' + nricval.length);
                    if (nricval.length != 9) {
                        if (isPopup) {
                            component.set("v.NricLengthValidation", true);
                            component.set("v.NricModalOpen", true);
                        } else {
                            component.set("v.NRICMessage", "Invalid NRIC and length of Nric is not matched");
                        }
                        nricIsValid = false;
                        
                    } else {
                        var firstchar = nricval.charAt(0);
                        var lastchar = nricval.charAt(nricval.length - 1);
                        if (firstchar != 'S' && firstchar != 's' && firstchar != 'F' && firstchar != 'f' &&
                            firstchar != 'T' && firstchar != 't' && firstchar != 'G' && firstchar != 'g') {
                            if (isPopup) {
                                component.set("v.NricFirstCharValidation", true);
                                component.set("v.NricModalOpen", true);
                            } else {
                                component.set("v.NRICMessage", "First character of NRIC is not valid");
                            }
                            nricIsValid = false;
                        }
                        var numericNric = nricval.substr(1, nricval.length - 2);
                        if (isNaN(numericNric)) {
                            if (isPopup) {
                                component.set("v.NricMiddleValValidation", true);
                                component.set("v.NricModalOpen", true);
                            } else {
                                component.set("v.NRICMessage", "Invalid: NRIC Middle values is not a number");
                            }
                            nricIsValid = false;
                        }
                    }
                    
                    //103 nricMap    --> {"0":"J","1":"Z","2":"I","3":"H","4":"G","5":"F","6":"E","7":"D","8":"C","9":"B","10":"A"}
                    //104 nricMapone --> {"1":"W","2":"U","3":"T","4":"R","5":"Q","6":"P","7":"N","8":"M","9":"L","10":"K"}
                    console.log('143 nricIsValid --> ' + nricIsValid);
                    if (nricIsValid) {
                        var nricsum = 2 * parseInt(nricval.substring(1, 2)) +
                            7 * parseInt(nricval.substring(2, 3)) +
                            6 * parseInt(nricval.substring(3, 4)) +
                            5 * parseInt(nricval.substring(4, 5)) +
                            4 * parseInt(nricval.substring(5, 6)) +
                            3 * parseInt(nricval.substring(6, 7)) +
                            2 * parseInt(nricval.substring(7, 8));
                        console.log('150 nricsum --> ' + nricsum);
                        if (nricval.substring(0, 1) == 'S') {
                            //  var nricremainder = Math.mod(nricsum , 11); 
                            var nricremainder = nricsum % 11;
                            console.log('153 nricremainder 	   --> ' + nricremainder);
                            console.log('154 nricMap.has 	   --> ' + nricMap.has(String(nricremainder).trim()));
                            console.log('155 nricMap.get 	   --> ' + nricMap.get(String(nricremainder).trim()));
                            console.log('159 nricval.substring --> ' + nricval.substring(8, 9));
                            
                            if (nricMap.has(String(nricremainder).trim()) && nricMap.get(String(nricremainder).trim()) != null &&
                                nricMap.get(String(nricremainder).trim()) != nricval.substring(8, 9)) {
                                if (isPopup) {
                                    component.set("v.NricEndCharValidation", true);
                                    component.set("v.NricModalOpen", true);
                                } else {
                                    component.set("v.NRICMessage", "Last character of NRIC is not valid");
                                }
                                nricIsValid = false;
                            }
                        }
                        else if (nricval.substring(0, 1) == 'T') {
                            //var nricremainder = Math.mod(nricsum + 4, 11);  
                            var nricremainder = (nricsum + 4) % 11;
                            if (nricMap.has(String(nricremainder).trim()) && nricMap.get(String(nricremainder).trim()) != null &&
                                nricMap.get(String(nricremainder).trim()) != nricval.substring(8, 9)) {
                                if (isPopup) {
                                    component.set("v.NricEndCharValidation", true);
                                    component.set("v.NricModalOpen", true);
                                } else {
                                    component.set("v.NRICMessage", "Last character of NRIC is not valid");
                                }
                                nricIsValid = false;
                            }
                        } else if (nricval.substring(0, 1) == 'F') {
                            // var nricremainder=Math.mod(nricsum , 11);               
                            var nricremainder = nricsum % 11;
                            if (nricMapone.has(String(nricremainder).trim()) && nricMapone.get(String(nricremainder).trim()) != null &&
                                nricMapone.get(String(nricremainder).trim()) != nricval.substring(8, 9)) {
                                if (isPopup) {
                                    component.set("v.NricEndCharValidation", true);
                                    component.set("v.NricModalOpen", true);
                                } else {
                                    component.set("v.NRICMessage", "Last character of NRIC is not valid");
                                }
                                nricIsValid = false;
                            }
                        } else if (nricval.substring(0, 1) == 'G') {
                            //var nricremainder=Math.mod(nricsum + 4, 11);               
                            var nricremainder = (nricsum + 4) % 11;
                            
                            console.log('153 G nricremainder 	   --> ' + nricremainder);
                            console.log('154 G nricMap.has 	       --> ' + nricMapone.has(String(nricremainder).trim()));
                            console.log('155 G nricMap.get 	       --> ' + nricMapone.get(String(nricremainder).trim()));
                            console.log('159 G nricval.substring   --> ' + nricval.substring(8, 9));
                            
                            if (nricMapone.has(String(nricremainder).trim()) && nricMapone.get(String(nricremainder).trim()) != null &&
                                nricMapone.get(String(nricremainder).trim()) != nricval.substring(8, 9)) {
                                if (isPopup) {
                                    component.set("v.NricEndCharValidation", true);
                                    component.set("v.NricModalOpen", true);
                                } else {
                                    component.set("v.NRICMessage", "Last character of NRIC is not valid");
                                }
                                nricIsValid = false;
                            }
                        }
                    }
                }
            } else {
                if (isPopup) {
                    component.set("v.NricNotNull", true);
                    component.set("v.NricModalOpen", true);
                } else {
                    component.set("v.NRICMessage", "NRIC should not be blank");
                }
                nricIsValid = false;
            }
        } else {
            nricIsValid = true;
        }
        
        console.log('196 nricIsValid --> ' + nricIsValid);
        if (nricIsValid)
            return true;
        else
            return false;
    }
    , validateFields: function (component, event) {
        
        var salutationField = component.find("salutationId");
        salutationField.reportValidity();
        var fNameField = component.find("fNameId");
        fNameField.reportValidity();
        var lNameField = component.find("lNameId");
        lNameField.reportValidity();
        var genderField = component.find("genderId");
        genderField.reportValidity();
        var emailField = component.find("emailId");
        emailField.reportValidity();
        var nationalityField = component.find("NationalityId");
        nationalityField.reportValidity();
        
    }
    , ShowToastEvent: function (component, event, Message, title, type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title: title,
            message: Message,
            duration: ' 2000',
            key: 'info_alt',
            type: type
        });
        toastEvent.fire();
    },
    UpdateRecord: function (component, event, fields) {
        console.log('in helper 34 fields ---> ' + JSON.stringify(fields.Mobile_No__c));
        console.log('35 Submit List ---> ' + component.get("v.IndexPosition"));
        
        var CurrentCourseRegistrationList = component.get("v.CourseRegistrationList");
        var iSDublicate = false;
        if (CurrentCourseRegistrationList.length > 0) {
            for (var i = 0; i < CurrentCourseRegistrationList.length; i++) {
                if (component.get("v.IndexPosition") != i) {
                    // if(CurrentCourseRegistrationList[i].First_Name__c.trim().toUpperCase()===fields[component.get("v.IndexPosition")].First_Name__c.trim().toString().toUpperCase() && CurrentCourseRegistrationList[i].Last_Name__c.trim().toUpperCase()===existingCourseRegistration[component.get("v.IndexPosition")].Last_Name__c.trim().toString().toUpperCase() && CurrentCourseRegistrationList[i].Email_Address__c.trim().toUpperCase()===existingCourseRegistration[component.get("v.IndexPosition")].Email_Address__c.trim().toString().toUpperCase()){
                    if (CurrentCourseRegistrationList[i].First_Name__c.trim().toUpperCase() === fields["First_Name__c"].toString().trim().toUpperCase() && CurrentCourseRegistrationList[i].Last_Name__c.trim().toUpperCase() === fields["Last_Name__c"].toString().trim().toUpperCase() && CurrentCourseRegistrationList[i].Email_Address__c.trim().toUpperCase() === fields["Email_Address__c"].toString().trim().toUpperCase()) {
                        
                        iSDublicate = true;
                    }
                }
            }
        }
        if (!iSDublicate) {
            var existingCourseRegistration = component.get("v.CourseRegistrationList");
            existingCourseRegistration[component.get("v.IndexPosition")] = fields;
            existingCourseRegistration[component.get("v.IndexPosition")].Id = component.get("v.EditcourseRegistrationId");
            if (!component.get("v.source")) {
                var checkVarmarketing = component.find("checkbox_marketing");
                if (checkVarmarketing.get("v.value"))
                    existingCourseRegistration[component.get("v.IndexPosition")].Marketing_Consent_Clause__c = true;
            } else {
                if (component.get("v.editMarketing"))
                    existingCourseRegistration[component.get("v.IndexPosition")].Marketing_Consent_Clause__c = true;
                else
                    existingCourseRegistration[component.get("v.IndexPosition")].Marketing_Consent_Clause__c = false;
            }
            existingCourseRegistration[component.get("v.IndexPosition")].PDPA_Consent_Clause__c = true;
            
            if (!$A.util.isEmpty(existingCourseRegistration[component.get("v.IndexPosition")].Need_User_Account__c)) {
                if (existingCourseRegistration[component.get("v.IndexPosition")].Need_User_Account__c == "Yes") {
                    existingCourseRegistration[component.get("v.IndexPosition")].isChecked = true;
                } else {
                    existingCourseRegistration[component.get("v.IndexPosition")].isChecked = false;
                }
            }
            
            
            component.set("v.CourseRegistrationList", existingCourseRegistration);
            component.set("v.EditcourseRegistrationId", "");
            component.set("v.iSEditRecord", false);
            this.ClearFieldValue(component, event);
            this.ShowToastEvent(component, event, $A.get("$Label.c.CourseRegistrationUpdateMsg"), 'Success', 'success');
        } else {
            this.ShowToastEvent(component, event, $A.get("$Label.c.CourseRegistrationDuplicateMsg"), 'Warning', 'warning');
        }
        
        if (!component.get("v.source")) {
            //component.find("checkbox_pdpa").set("v.value",false);
            //component.find("checkbox_marketing").set("v.value",false);
        }
    },
    ClearFieldValue: function (component, event) {
        
        component.find('salutationId').set('v.value', '');
        component.find('fNameId').set('v.value', '');
        component.find('lNameId').set('v.value', '');
        component.find('prefCertificateId').set('v.value', '');
        component.find('genderId').set('v.value', '');
        component.find('emailId').set('v.value', '');
        component.find('MblenoId').set('v.value', '');
        component.find('NationalityId').set('v.value', '');
        component.find('ofceNoId').set('v.value', '');
        component.find('EmploymentStatus').set('v.value', '');
        component.find('JobTitle').set('v.value', '');
        component.find('DesignationLevel').set('v.value', '');
        component.find('EmploymentStatus').set('v.value', '');
        //2021-09-23 Poon Koon: Clear Sub Business Unit fields
        component.find('SubBusinessUnitName').set('v.value', '');
        component.find('SubBusinessUnitCode').set('v.value', '');
        component.find('NeedUserAccount').set('v.value', '');
        component.find('courseRun').set('v.value', '');
        component.find('ContactRecordId').set('v.value', '');
        
        
        if (component.get('v.piiSection')) {
            component.find('NricTypeId').set('v.value', '');
            component.find('NricId').set('v.value', '');
            component.find('dobId').set('v.value', '');
        }
    },
    createLearnerFunding: function (component, event) {
        //// alert('calling createLearnerFunding i helper')
        var buttonLabel = component.get('v.buttonlabel');
        //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
        let nonMemberTotalFee = parseInt(component.get("v.NonMemberPrice"));
		let promoNonMemberValue = parseInt(component.get("v.PromoCodeNonMemberValue"));
        //2022-02-07 Daksh Mandowara : End changes
        if (buttonLabel == 'Draft') {
            component.set("v.isDraftOpen", true);
        }
        if (buttonLabel == 'Submit') {
            //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
            if(nonMemberTotalFee<=0 || promoNonMemberValue<=0){
                component.set("v.PaymentWithZeroFeeModalOpen", true); 
            }else{
                component.set("v.PaymentModalOpen", true); 
            }
            // 2022-02-07 Daksh Mandowara : End changes
            
        }
        
    },
    
    handlerForSubmit: function (component, event) {
        console.log('handlerForSubmit');
        component.set("v.Spinner", true);
        var crCode = component.get("v.courseRunCode");
        var getCourseRun = component.get('c.getCourseRunRecord');
        getCourseRun.setParams({ courseRunCode: crCode });
        getCourseRun.setCallback(this, function (response) {
            if (response.getState() === "SUCCESS") {
                var courseRun = response.getReturnValue();
                var cRunCapacity = courseRun.Capacity__c;
                var cRun_regCount = courseRun.No_of_Participant__c;
                if ($A.util.isEmpty(cRun_regCount)) {
                    cRun_regCount = 0;
                }
                if (cRunCapacity == cRun_regCount || cRunCapacity < cRun_regCount) {
                    component.set("v.Spinner", false);
                    component.set("v.isOpen", true);
                } else {
                    component.set('v.buttonlabel', 'Submit');
                    component.set("v.Spinner", false);
                    if ($A.util.isEmpty(component.get("v.CourseRegistrationMasterId"))) {
                        this.SaveRecord(component, event);
                    }
                    else if (!$A.util.isEmpty(component.get("v.CourseRegistrationMasterId"))) {
                        if (!$A.util.isEmpty(component.get("v.DeleteCourseRegistrationList")))
                            this.DeleteRecord(component, event);
                        this.UpdateCourseRegistrationRecord(component, event);
                    }
                    
                }
            } else if (response.getState() == "ERROR") {
                component.set("v.Spinner", false);
                var errors = response.getError();
                alert(errors[0].message);
            }
        });
        $A.enqueueAction(getCourseRun);
    },
    
    handlerForDraft: function (component, event) {
        console.log('handlerForDraft');
        component.set("v.Spinner", true);
        var crCode = component.get("v.courseRunCode");
        var getCourseRun = component.get('c.getCourseRunRecord');
        getCourseRun.setParams({ courseRunCode: crCode });
        getCourseRun.setCallback(this, function (response) {
            if (response.getState() === "SUCCESS") {
                var courseRun = response.getReturnValue();
                var cRunCapacity = courseRun.Capacity__c;
                var regChildRecs = courseRun.Course_Registrations__r;
                var cRun_regCount = 0;
                if (!$A.util.isEmpty(regChildRecs)) {
                    cRun_regCount = regChildRecs.length;
                }
                if (cRunCapacity == cRun_regCount || cRunCapacity < cRun_regCount) {
                    component.set("v.Spinner", false);
                    component.set("v.isOpen", true);
                } else {
                    component.set('v.buttonlabel', 'Draft');
                    component.set("v.Spinner", false);
                    if ($A.util.isEmpty(component.get("v.CourseRegistrationMasterId"))) {
                        this.SaveRecord(component, event);
                    }
                    else if (!$A.util.isEmpty(component.get("v.CourseRegistrationMasterId"))) {
                        if (!$A.util.isEmpty(component.get("v.DeleteCourseRegistrationList")))
                            this.DeleteRecord(component, event);
                        this.UpdateCourseRegistrationRecord(component, event);
                    }
                    
                }
            } else if (response.getState() == "ERROR") {
                component.set("v.Spinner", false);
                var errors = response.getError();
                alert(errors[0].message);
            }
        });
        $A.enqueueAction(getCourseRun);
        
    },
    
    SaveRecord: function (component, event) {
        //2022-03-09 Daksh Mandowara : get full fee with gst record
        var fullFeeWithGST = parseInt(component.get("v.courseRunRecord.Course__r.Full_Fee_with_GST__c"));
        console.log('***************************************'+fullFeeWithGST);
        //End Changes by Daksh Mandowara
        var existingUserEmail = [];
        var emailIndex = [];
        //let indexOfEmail = new Map();
        //
        console.log('on mapCheckGrant ' + JSON.stringify(component.get("v.mapCheckGrant")));
        console.log('on Save ' + component.get("v.PromoCodeId"));
        component.set("v.Spinner", true);
        
        
        var buttonLabel = component.get('v.buttonlabel'); 
        var sRegistrationStatus = '';
        var CourseRegistration = component.get("v.CourseRegistrationList");
        for (var i = 0; i < CourseRegistration.length; i++) {
            if (buttonLabel == 'Draft') {
                CourseRegistration[i].Registration_Status__c = 'Draft'; sRegistrationStatus = 'Draft';
            } if (buttonLabel == 'Submit') {
                    CourseRegistration[i].Registration_Status__c = 'New'; sRegistrationStatus = 'New';                
            }
            CourseRegistration[i].Sync_Learner_s_Record__c = true;
            CourseRegistration[i].Course_Run_Id__c = component.get("v.courseRunRecord.Id");
            var accountRecordtype = component.get("v.contactRecord.Account.RecordType.DeveloperName");
            if (accountRecordtype == 'B2B_Account') {
                CourseRegistration[i].Company_UEN_No__c = component.get("v.contactRecord.Account.UEN_No__c");
            }
            if (!$A.util.isEmpty(CourseRegistration[i].isChecked)) {
                if (CourseRegistration[i].isChecked) {
                    CourseRegistration[i].Need_User_Account__c = "Yes";
                    existingUserEmail.push(CourseRegistration[i].Email_Address__c.trim().toLowerCase());
                    emailIndex.push((i + 1));
                    //indexOfEmail.set(CourseRegistration[i].Email_Address__c,(i+1));
                }
                else
                    CourseRegistration[i].Need_User_Account__c = "No";
            }
            
            component.set("v.CourseRegistrationList", CourseRegistration);
        }
        console.log(component.get("v.CourseRegistrationList"));
        console.log('existingUserEmail --> ' + existingUserEmail);
        console.log('emailIndex --> ' + JSON.stringify(emailIndex));
        
        if (!$A.util.isEmpty(existingUserEmail)) {
            var checkUserEmail = component.get('c.checkUserWithContact');
            checkUserEmail.setParams({
                "emailList": existingUserEmail
            });
            checkUserEmail.setCallback(this, function (response) {
                if (response.getState() === "SUCCESS") {
                    console.log('emailIndex Response --> ' + JSON.stringify(response.getReturnValue()));
                    var sMsgEmail = '';
                    if (!$A.util.isEmpty(response.getReturnValue())) {
                        for (var i = 0; i < response.getReturnValue().length; i++) {
                            var emailIndexOf = existingUserEmail.indexOf(response.getReturnValue()[i].trim().toLowerCase());
                            if (emailIndexOf != -1)
                                sMsgEmail += 'Row ' + emailIndex[emailIndexOf] + ', User with email ' + response.getReturnValue()[i] + ' already present \n';
                        }
                        if (!$A.util.isEmpty(sMsgEmail)) {
                            component.set("v.Spinner", false);
                            this.ShowToastEvent(component, event, sMsgEmail, 'Error', 'error');
                        }
                    } else {
                        console.log("*********** 397 ***************** ");
                        console.log("CourseRegistrationList --> " + JSON.stringify(component.get("v.CourseRegistrationList")));
                        console.log("courseRunCode --> " + component.get('v.courseRunCode'));
                        console.log("RegistrationStatus --> " + sRegistrationStatus);
                        console.log("lookupContactId --> " + component.get("v.lookupContactId"));
                        console.log("UserId --> " + $A.util.isEmpty(component.get('v.SelectedUserId')) ? '' : component.get('v.SelectedUserId'));
                        console.log("PromoCode --> " + $A.util.isEmpty(component.get('v.PromoCodeId')) ? null : component.get('v.PromoCodeId'));
                        console.log("mapLearnerfunding --> " + $A.util.isEmpty(component.get('v.mapCheckGrant')) ? null : component.get('v.mapCheckGrant'));
                        
                        
                        var action = component.get("c.SaveCourseRegistration");
                        action.setParams({
                            "lstCourseRegistration": JSON.stringify(component.get("v.CourseRegistrationList")),
                            "courseRunCode": component.get('v.courseRunCode'),
                            "RegistrationStatus": sRegistrationStatus,
                            "lookupContactId": component.get("v.lookupContactId"),
                            "UserId": $A.util.isEmpty(component.get('v.SelectedUserId')) ? '' : component.get('v.SelectedUserId'),
                            "PromoCode": $A.util.isEmpty(component.get('v.PromoCodeId')) ? null : component.get('v.PromoCodeId'),
                            "mapLearnerfunding": $A.util.isEmpty(component.get('v.mapCheckGrant')) ? null : component.get('v.mapCheckGrant')
                        });
                        action.setCallback(this, function (response) {
                            var state = response.getState();
                            console.log('state --> ' + state);
                            if (response.getState() == "SUCCESS") {
                                var courseRegId = response.getReturnValue();
                                component.set("v.Spinner", false);
                                component.set("v.courseRegistrationId", courseRegId.courseRegId);
                                component.set("v.listcourseRegId", courseRegId.setOfcourseReg);
                                if (buttonLabel == 'Draft') {
                                    //component.set("v.isDraftOpen", true);
                                    var courseRunCode = component.get("v.courseRunCode");
                                    if (!component.get("v.source")) {
                                        var urlEvent = $A.get("e.force:navigateToURL");
                                        urlEvent.setParams({
                                            "url": "/s/bulk-registration/?courseruncode=" + courseRunCode
                                        });
                                        urlEvent.fire();
                                    }
                                    else {
                                        //alert("navigation is calling in Save")
                                        component.set("v.SaveAsDraftPopUpForPE", true);
                                    }
                                }
                                if (buttonLabel == 'Submit') {
                                    // 2022-02-18 Daksh Mandowara : Generaing invoice on zero fee registration
                                    var courseRecordType = component.get("v.courseRunRecord.CourseRecordType__c");
                                    try{
                                        if (courseRecordType == 'Funded_Course') {
                                            
                                            if(parseInt(fullFeeWithGST)<=0 || parseInt(component.get("v.PromoCodeFullfeeValue"))<=0){
                                            }
                                        }else{
                                            if(parseInt(component.get("v.PromoCodeNonMemberValue"))<=0 || parseInt(component.get("v.NonMemberPrice"))<=0){
                                                component.set("v.PaymentModalOpen", false);
                                                //  component.set("v.selTabId" , 'Payment');
                                                let invoiceIdPush;
                                                let regId = component.get("v.courseRegistrationId");        
                                                var getinvoice = component.get('c.returnInvoice');
                                                getinvoice.setParams({courseRegId: regId,listcourseRegId:component.get("v.listcourseRegId")});
                                                getinvoice.setCallback(this, function(response) { 
                                                    if(response.getState() === "SUCCESS") {
                                                        console.log('success ');
                                                        var invoiceId = response.getReturnValue(); 
                                                        component.set("v.invoiceId" , invoiceId); 
                                                        invoiceIdPush = invoiceId;
                                                        
                                                    } else if(response.getState() == "ERROR"){
                                                        var errors = response.getError();    
                                                        console.log(errors[0].message);
                                                    }
                                                }); 
                                                $A.enqueueAction(getinvoice);
                                                
                                            }
                                            
                                        }
                                    }catch(e){
                                        console.log(e);
                                    }
                                    
                                    // End changes by Daksh Mandowara
                                    var provider = component.get("v.courseRunRecord.Course__r.Provider__c");
                                    
                                    /* alert(" on save as Draft courseRecordType --> "+courseRecordType);
                    alert(" on save as Draft memberCheckbox --> "+component.get("v.memberCheckbox"));
                    alert(" on save as Draft provider --> "+provider);*/
                                    if (courseRecordType == 'Funded_Course') {
                                        if (!component.get("v.source")){
                                            component.set("v.isExecutiveModalOpen", true);
                                        }else {
                                            component.set("v.SubmitPopUpForPE", true);
                                        }
                                    }
                                    else {
                                        if (!component.get("v.memberCheckbox") && provider == 'SIM') {
                                            if (!component.get("v.source"))
                                                //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                                                
                                                if(component.get("v.PromoCodeNonMemberValue")==="0" || component.get("v.NonMemberPrice")<=0){
                                                    component.set("v.PaymentWithZeroFeeModalOpen", true); 
                                                }else{
                                                    component.set("v.PaymentModalOpen", true); 
                                                }
                                            // 2022-02-07 Daksh Mandowara : End changes
                                            else {
                                                component.set("v.SubmitPopUpForPE", true);
                                            }
                                        }
                                        else {
                                            if (!component.get("v.source"))
                                                //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                                                
                                                if(component.get("v.PromoCodeNonMemberValue")==="0" || component.get("v.NonMemberPrice")==="0"){
                                                    component.set("v.PaymentWithZeroFeeModalOpen", true); 
                                                }else{
                                                    component.set("v.PaymentModalOpen", true); 
                                                }
                                            // 2022-02-07 Daksh Mandowara : End changes
                                            else {
                                                component.set("v.SubmitPopUpForPE", true);
                                            }
                                        }
                                    }
                                }
                            } else if (state === "ERROR") {
                                var errors = response.getError();
                                if (errors) {
                                    component.set("v.Spinner", false);
                                    if (errors[0] && errors[0].message) {
                                        console.log("Error message: " +
                                                    errors[0].message);
                                        //alert("Error --> "+errors[0].message);
                                        this.ShowToastEvent(component, event, "Error occured! Please contact the system admin.", 'Error', 'error');
                                    }
                                } else {
                                    console.log("Unknown error");
                                }
                            }
                        });
                        $A.enqueueAction(action);
                        
                    }
                }
            });
            $A.enqueueAction(checkUserEmail);
        } else {
            
            
            
            console.log("*********** 495 ***************** ");
            console.log("CourseRegistrationList --> " + JSON.stringify(component.get("v.CourseRegistrationList")));
            console.log("courseRunCode --> " + component.get('v.courseRunCode'));
            console.log("RegistrationStatus --> " + sRegistrationStatus);
            console.log("lookupContactId --> " + component.get("v.lookupContactId"));
            console.log("UserId --> " + $A.util.isEmpty(component.get('v.SelectedUserId')) ? '' : component.get('v.SelectedUserId'));
            console.log("PromoCode --> " + $A.util.isEmpty(component.get('v.PromoCodeId')) ? null : component.get('v.PromoCodeId'));
            console.log("mapLearnerfunding --> " + $A.util.isEmpty(component.get('v.mapCheckGrant')) ? null : component.get('v.mapCheckGrant'));
            
            
            
            var action = component.get("c.SaveCourseRegistration");
            action.setParams({
                "lstCourseRegistration": JSON.stringify(component.get("v.CourseRegistrationList")),
                "courseRunCode": component.get('v.courseRunCode'),
                "RegistrationStatus": sRegistrationStatus,
                "lookupContactId": component.get("v.lookupContactId"),
                "UserId": $A.util.isEmpty(component.get('v.SelectedUserId')) ? '' : component.get('v.SelectedUserId'),
                "PromoCode": $A.util.isEmpty(component.get('v.PromoCodeId')) ? null : component.get('v.PromoCodeId'),
                "mapLearnerfunding": $A.util.isEmpty(component.get('v.mapCheckGrant')) ? null : component.get('v.mapCheckGrant')
            });
            action.setCallback(this, function (response) {
                
                var state = response.getState();
                console.log('state --> ' + state)
                if (response.getState() == "SUCCESS") {
                    var courseRegId = response.getReturnValue();
                    component.set("v.Spinner", false);
                    component.set("v.courseRegistrationId", courseRegId.courseRegId);
                    component.set("v.listcourseRegId", courseRegId.setOfcourseReg);
                    if (buttonLabel == 'Draft') {
                        //component.set("v.isDraftOpen", true);
                        var courseRunCode = component.get("v.courseRunCode");
                        if (!component.get("v.source")) {
                            var urlEvent = $A.get("e.force:navigateToURL");
                            urlEvent.setParams({
                                "url": "/s/bulk-registration/?courseruncode=" + courseRunCode
                            });
                            urlEvent.fire();
                        }
                        else {
                            //alert("navigation is calling in Save")
                            component.set("v.SaveAsDraftPopUpForPE", true);
                        }
                    }
                    if (buttonLabel == 'Submit') {
                        // 2022-02-18 Daksh Mandowara : trigger invoice generate flow
                        var courseRecordType = component.get("v.courseRunRecord.CourseRecordType__c");
                        try{
                            
                            if (courseRecordType == 'Funded_Course') {                                
                                if(parseInt(fullFeeWithGST)<=0 || parseInt(component.get("v.PromoCodeFullfeeValue"))<=0){
                                 }      
                             }else{
                                 
                                if(parseInt(component.get("v.PromoCodeNonMemberValue"))<=0 || parseInt(component.get("v.NonMemberPrice"))<=0){
                                component.set("v.PaymentModalOpen", false);
                                //  component.set("v.selTabId" , 'Payment');
                                let invoiceIdPush;
                                let regId = component.get("v.courseRegistrationId");        
                                var getinvoice = component.get('c.returnInvoice');
                                getinvoice.setParams({courseRegId: regId,listcourseRegId:component.get("v.listcourseRegId")});
                                getinvoice.setCallback(this, function(response) { 
                                    if(response.getState() === "SUCCESS") {
                                        console.log('success');
                                        
                                        var invoiceId = response.getReturnValue(); 
                                        //if(invoiceId != null || invoiceId != undefined) {
                                        component.set("v.invoiceId" , invoiceId); 
                                        invoiceIdPush = invoiceId;
                                       // component.set("v.selTabId" , 'Payment');   
                                        //}
                                        
                                    } else if(response.getState() == "ERROR"){
                                        var errors = response.getError();    
                                    console.log(errors[0].message);
                                }
                            }); 
                            $A.enqueueAction(getinvoice);
                            
                                }
                             }
                        }catch(e){
                            console.log(e);
                        }
                        
                        // End changes by Daksh Mandowara
                        var provider = component.get("v.courseRunRecord.Course__r.Provider__c");
                        
                        /* alert(" on save as Draft courseRecordType --> "+courseRecordType);
                    alert(" on save as Draft memberCheckbox --> "+component.get("v.memberCheckbox"));
                    alert(" on save as Draft provider --> "+provider);*/
                        //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                        let nonMemberTotalFee = component.get("v.NonMemberPrice");
                        let promoNonMemberValue = component.get("v.PromoCodeNonMemberValue");
                        console.log('**********************'+component.get("v.PromoCodeFullfeeValue"));
                        //2022-02-07 Daksh Mandowara : End changes
                        if (courseRecordType == 'Funded_Course') {
                            if (!component.get("v.source")){
                                component.set("v.isExecutiveModalOpen", true);
                            }else {
                                component.set("v.SubmitPopUpForPE", true);
                            }
                        }
                        else {
                            if (!component.get("v.memberCheckbox") && provider == 'SIM') {
                                if (!component.get("v.source"))
                                    //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                                    if(parseInt(promoNonMemberValue)<=0 || parseInt(nonMemberTotalFee)<=0){
                                        component.set("v.PaymentWithZeroFeeModalOpen", true); 
                                    }else{
                                        component.set("v.PaymentModalOpen", true); 
                                    }
                                // 2022-02-07 Daksh Mandowara : End changes
                                else {
                                    component.set("v.SubmitPopUpForPE", true);
                                }
                            }
                            else {
                                if (!component.get("v.source"))
                                    //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                                    if(parseInt(promoNonMemberValue)<=0 || parseInt(nonMemberTotalFee)<=0){
                                        component.set("v.PaymentWithZeroFeeModalOpen", true); 
                                    }else{
                                        component.set("v.PaymentModalOpen", true); 
                                    }
                                // 2022-02-07 Daksh Mandowara : End changes
                                else {
                                    component.set("v.SubmitPopUpForPE", true);
                                }
                            }
                        }
                    }
                } else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        component.set("v.Spinner", false);
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " +
                                        errors[0].message);
                            //alert("Error --> "+errors[0].message);
                            this.ShowToastEvent(component, event, "Error occured! Please contact the system admin.", 'Error', 'error');
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
            });
            $A.enqueueAction(action);
        }
        
        
    },
    UpdateCourseRegistrationRecord: function (component, event) {
        
        var existingUserEmail = [];
        var emailIndex = [];
        let indexOfEmail = new Map();
        
        console.log('on update ' + component.get("v.PromoCodeId"));
        
        component.set("v.Spinner", true);
        // console.log("update list --> "+JSON.stringify(component.get("v.CourseRegistrationList")))
        // console.log("CourseRegistrationMasterId list --> "+component.get("v.CourseRegistrationMasterId"))
        var buttonLabel = component.get('v.buttonlabel'); var sRegistrationStatus = '';
        var CourseRegistration = component.get("v.CourseRegistrationList");
        for (var i = 0; i < CourseRegistration.length; i++) {
            if (buttonLabel == 'Draft') {
                CourseRegistration[i].Registration_Status__c = 'Draft'; sRegistrationStatus = 'Draft';
            } if (buttonLabel == 'Submit') {
                CourseRegistration[i].Registration_Status__c = 'New'; sRegistrationStatus = 'New';
            }
            CourseRegistration[i].Sync_Learner_s_Record__c = true;
            var accountRecordtype = component.get("v.contactRecord.Account.RecordType.DeveloperName");
            if (accountRecordtype == 'B2B_Account') {
                CourseRegistration[i].Company_UEN_No__c = component.get("v.contactRecord.Account.UEN_No__c");
            }
            if (!$A.util.isEmpty(CourseRegistration[i].isChecked)) {
                if (CourseRegistration[i].isChecked) {
                    CourseRegistration[i].Need_User_Account__c = "Yes";
                    existingUserEmail.push(CourseRegistration[i].Email_Address__c.trim().toLowerCase());
                    emailIndex.push((i + 1));
                }
                else
                    CourseRegistration[i].Need_User_Account__c = "No";
            }
            component.set("v.CourseRegistrationList", CourseRegistration);
        }
        
        //console.log('lIST TO UPDATE --> '+JSON.stringify(component.get("v.CourseRegistrationList")));
        // console.log('CourseRegistrationMasterId --> '+component.get("v.CourseRegistrationMasterId"));
        // console.log('RegistrationStatus --> '+sRegistrationStatus);
        // console.log('lookupContactId --> '+component.get("v.lookupContactId"));
        // console.log('UserId --> '+component.get("v.SelectedUserId"));
        // console.log('courseRunCode --> '+component.get("v.courseRunCode"));
        
        if (!$A.util.isEmpty(existingUserEmail)) {
            var checkUserEmail = component.get('c.checkUserWithContact');
            checkUserEmail.setParams({
                "emailList": existingUserEmail
            });
            checkUserEmail.setCallback(this, function (response) {
                if (response.getState() === "SUCCESS") {
                    var sMsgEmail = '';
                    if (!$A.util.isEmpty(response.getReturnValue())) {
                        for (var i = 0; i < response.getReturnValue().length; i++) {
                            var emailIndexOf = existingUserEmail.indexOf(response.getReturnValue()[i].trim().toLowerCase());
                            if (emailIndexOf != -1)
                                sMsgEmail += 'Row ' + emailIndex[emailIndexOf] + ', User with email ' + response.getReturnValue()[i] + ' already present \n';
                        }
                        if (!$A.util.isEmpty(sMsgEmail)) {
                            component.set("v.Spinner", false);
                            this.ShowToastEvent(component, event, sMsgEmail, 'Error', 'error');
                        }
                    } else {
                        console.log(" 625 in else PromoCodeId " + $A.util.isEmpty(component.get('v.PromoCodeId')) ? null : component.get('v.PromoCodeId'));
                        var action = component.get("c.UpdateCourseRegistration");
                        action.setParams({
                            "lstCourseRegistration": JSON.stringify(component.get("v.CourseRegistrationList")),
                            "CourseRegistrationMasterId": component.get("v.CourseRegistrationMasterId"),
                            "RegistrationStatus": sRegistrationStatus,
                            "lookupContactId": component.get("v.lookupContactId"),
                            "UserId": component.get("v.SelectedUserId"),
                            "courseRunCode": component.get('v.courseRunCode'),
                            "PromoCode": $A.util.isEmpty(component.get('v.PromoCodeId')) ? "" : component.get('v.PromoCodeId'),
                            "mapLearnerfunding": $A.util.isEmpty(component.get('v.mapCheckGrant')) ? null : component.get('v.mapCheckGrant')
                        });
                        action.setCallback(this, function (response) {
                            var state = response.getState();
                            // alert('buttonLabel ---> '+buttonLabel)
                            if (response.getState() == "SUCCESS") {
                                var courseRegId = response.getReturnValue();
                                console.log('177 courseRegId --> ' + courseRegId);
                                //component.set("v.courseRegistrationId",courseRegId);
                                component.set("v.courseRegistrationId", courseRegId.courseRegId);
                                component.set("v.listcourseRegId", courseRegId.setOfcourseReg);
                                component.set("v.Spinner", false);
                                if (buttonLabel == 'Draft') {
                                    //component.set("v.isDraftOpen", true);
                                    var courseRunCode = component.get("v.courseRunCode");
                                    if (!component.get("v.source")) {
                                        var urlEvent = $A.get("e.force:navigateToURL");
                                        urlEvent.setParams({
                                            "url": "/s/bulk-registration/?courseruncode=" + courseRunCode
                                        });
                                        urlEvent.fire();
                                    } else {
                                        //  alert("navigation is calling in update");
                                        component.set("v.SaveAsDraftPopUpForPE", true);
                                    }
                                    
                                } if (buttonLabel == 'Submit') {
                                    var provider = component.get("v.courseRunRecord.Course__r.Provider__c");
                                    var courseRecordType = component.get("v.courseRunRecord.CourseRecordType__c");
                                    //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                                    let nonMemberTotalFee = parseInt(component.get("v.NonMemberPrice"));
                                    let promoNonMemberValue = parseInt(component.get("v.PromoCodeNonMemberValue"));
                                    //2022-02-07 Daksh Mandowara : End changes
                                    // alert("189 provider ---> "+provider+  "  courseRecordType --> "+courseRecordType +"   component.get ---> "+component.get("v.memberCheckbox"));
                                    if (courseRecordType == 'Funded_Course') {
                                        component.set("v.isExecutiveModalOpen", true);
                                    }
                                    else {
                                        if (!component.get("v.memberCheckbox") && provider == 'SIM') {
                                            if (!component.get("v.source"))
                                                //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                                                if(promoNonMemberValue<=0 || nonMemberTotalFee<=0){
                                                    component.set("v.PaymentWithZeroFeeModalOpen", true); 
                                                }else{
                                                    component.set("v.PaymentModalOpen", true); 
                                                }
                                            // 2022-02-07 Daksh Mandowara : End changes
                                            else {
                                                component.set("v.SubmitPopUpForPE", true);
                                            }
                                        }
                                        else {
                                            if (!component.get("v.source"))
                                                //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                                                if(promoNonMemberValue<=0 || nonMemberTotalFee<=0){
                                                    component.set("v.PaymentWithZeroFeeModalOpen", true); 
                                                }else{
                                                    component.set("v.isExecutiveModalOpen", true); 
                                                }
                                            // 2022-02-07 Daksh Mandowara : End changes
                                            else {
                                                component.set("v.SubmitPopUpForPE", true);
                                            }
                                        }
                                    }
                                }
                            } else if (state === "ERROR") {
                                component.set("v.Spinner", false);
                                var errors = response.getError();
                                if (errors) {
                                    if (errors[0] && errors[0].message) {
                                        console.log("Error message: " +
                                                    errors[0].message);
                                        this.ShowToastEvent(component, event, "Error occured! Please contact the system admin.", 'Error', 'error');
                                    }
                                } else {
                                    console.log("Unknown error");
                                }
                            }
                        });
                        $A.enqueueAction(action);
                        
                    }
                }
            });
            $A.enqueueAction(checkUserEmail);
        }
        else {
            
            console.log(" 708 in else PromoCodeId " + component.get('v.PromoCodeId'));
            var action = component.get("c.UpdateCourseRegistration");
            action.setParams({
                "lstCourseRegistration": JSON.stringify(component.get("v.CourseRegistrationList")),
                "CourseRegistrationMasterId": component.get("v.CourseRegistrationMasterId"),
                "RegistrationStatus": sRegistrationStatus,
                "lookupContactId": component.get("v.lookupContactId"),
                "UserId": component.get("v.SelectedUserId"),
                "courseRunCode": component.get('v.courseRunCode'),
                "PromoCode": component.get('v.PromoCodeId'),
                "mapLearnerfunding": $A.util.isEmpty(component.get('v.mapCheckGrant')) ? null : component.get('v.mapCheckGrant')
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                // alert('buttonLabel ---> '+buttonLabel)
                if (response.getState() == "SUCCESS") {
                    var courseRegId = response.getReturnValue();
                    console.log('177 courseRegId --> ' + courseRegId);
                    //component.set("v.courseRegistrationId",courseRegId);
                    component.set("v.courseRegistrationId", courseRegId.courseRegId);
                    component.set("v.listcourseRegId", courseRegId.setOfcourseReg);
                    component.set("v.Spinner", false);
                    if (buttonLabel == 'Draft') {
                        //component.set("v.isDraftOpen", true);
                        var courseRunCode = component.get("v.courseRunCode");
                        if (!component.get("v.source")) {
                            var urlEvent = $A.get("e.force:navigateToURL");
                            urlEvent.setParams({
                                "url": "/s/bulk-registration/?courseruncode=" + courseRunCode
                            });
                            urlEvent.fire();
                        } else {
                            //  alert("navigation is calling in update");
                            component.set("v.SaveAsDraftPopUpForPE", true);
                        }
                        
                    } if (buttonLabel == 'Submit') {
                        var provider = component.get("v.courseRunRecord.Course__r.Provider__c");
                        var courseRecordType = component.get("v.courseRunRecord.CourseRecordType__c");
                        //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                        let nonMemberTotalFee = parseInt(component.get("v.NonMemberPrice"));
                        let promoNonMemberValue = parseInt(component.get("v.PromoCodeNonMemberValue"));
                        //2022-02-07 Daksh Mandowara : End changes
                        // alert("189 provider ---> "+provider+  "  courseRecordType --> "+courseRecordType +"   component.get ---> "+component.get("v.memberCheckbox"));
                        if (courseRecordType == 'Funded_Course') {
                            component.set("v.isExecutiveModalOpen", true);
                        }
                        else {
                            if (!component.get("v.memberCheckbox") && provider == 'SIM') {
                                if (!component.get("v.source"))
                                    //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                                    if(promoNonMemberValue<=0 || nonMemberTotalFee<=0){
                                        component.set("v.PaymentWithZeroFeeModalOpen", true); 
                                    }else{
                                        component.set("v.PaymentModalOpen", true); 
                                    }
                                // 2022-02-07 Daksh Mandowara : End changes
                                else {
                                    component.set("v.SubmitPopUpForPE", true);
                                }
                            }
                            else {
                                if (!component.get("v.source"))
                                    //2022-02-07 Daksh Mandowara : Condition for payment modal with zero fee and without zero fee
                                    if(promoNonMemberValue<=0 || nonMemberTotalFee<=0){
                                        component.set("v.PaymentWithZeroFeeModalOpen", true); 
                                    }else{
                                        component.set("v.isExecutiveModalOpen", true);
                                    }
                                // 2022-02-07 Daksh Mandowara : End changes
                                else {
                                    component.set("v.SubmitPopUpForPE", true);
                                }
                            }
                        }
                    }
                } else if (state === "ERROR") {
                    component.set("v.Spinner", false);
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " +
                                        errors[0].message);
                            this.ShowToastEvent(component, event, "Error occured! Please contact the system admin.", 'Error', 'error');
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
            });
            $A.enqueueAction(action);
            
        }
        
        
    },
    DeleteRecord: function (component, event) {
        component.set("v.Spinner", true);
        console.log("DeleteCourseRegistrationList ---> " + component.get("v.DeleteCourseRegistrationList"))
        var action = component.get("c.DeleteCourseRegistration");
        action.setParams({
            "lstDeleteCourseRegistration": component.get("v.DeleteCourseRegistrationList")
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            component.set("v.Spinner", false);
            ////  alert("response ---> "+response.getState())
            if (response.getState() == "SUCCESS") {
                console.log("SUCCESS message: " + response.getState());
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                        this.ShowToastEvent(component, event, "Error occured! Please contact the system admin.", 'Error', 'error');
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    getIdentificationType: function (component, event, helper) {
        var getIdentificationType = component.get('c.getIdentificationType');
        getIdentificationType.setParams({});
        let myMap = new Map();
        getIdentificationType.setCallback(this, function (response) {
            console.log('response.getState() ---> ' + response.getState());
            if (response.getState() === "SUCCESS") {
                if (response.getReturnValue().length > 0) {
                    for (var i = 0; i < response.getReturnValue().length; i++) {
                        myMap.set(response.getReturnValue()[i], response.getReturnValue()[i])
                    }
                    component.set("v.mapIdentificationType", myMap);
                }
            } else if (response.getState() == "ERROR") {
                var errors = response.getError();
                console.log(errors[0].message);
            }
        });
        $A.enqueueAction(getIdentificationType);
    },
    getNationality: function (component, event, helper) {
        var getNationality = component.get('c.getNationality');
        let myMap = new Map();
        getNationality.setParams({});
        getNationality.setCallback(this, function (response) {
            console.log('response.getState() ---> ' + response.getState());
            if (response.getState() === "SUCCESS") {
                if (response.getReturnValue().length > 0) {
                    for (var i = 0; i < response.getReturnValue().length; i++) {
                        myMap.set(response.getReturnValue()[i], response.getReturnValue()[i])
                    }
                    component.set("v.mapnationality", myMap);
                }
            } else if (response.getState() == "ERROR") {
                var errors = response.getError();
                console.log(errors[0].message);
            }
        });
        $A.enqueueAction(getNationality);
    },
    getEmploymentStatus: function (component, event, helper) {
        var getEmploymentStatus = component.get('c.getEmploymentStatus');
        let myMap = new Map();
        getEmploymentStatus.setParams({});
        getEmploymentStatus.setCallback(this, function (response) {
            console.log('response.getState() ---> ' + response.getState());
            if (response.getState() === "SUCCESS") {
                if (response.getReturnValue().length > 0) {
                    for (var i = 0; i < response.getReturnValue().length; i++) {
                        myMap.set(response.getReturnValue()[i], response.getReturnValue()[i])
                    }
                    component.set("v.mapemploymentStatus", myMap);
                }
            } else if (response.getState() == "ERROR") {
                var errors = response.getError();
                console.log(errors[0].message);
            }
        });
        $A.enqueueAction(getEmploymentStatus);
    },
    getDesignationLevel: function (component, event, helper) {
        var getDesignationLevel = component.get('c.getDesignationLevel');
        let myMap = new Map();
        getDesignationLevel.setParams({});
        getDesignationLevel.setCallback(this, function (response) {
            console.log('response.getState() ---> ' + response.getState());
            if (response.getState() === "SUCCESS") {
                if (response.getReturnValue().length > 0) {
                    for (var i = 0; i < response.getReturnValue().length; i++) {
                        myMap.set(response.getReturnValue()[i], response.getReturnValue()[i])
                    }
                    component.set("v.mapdesignationLevel", myMap);
                }
            } else if (response.getState() == "ERROR") {
                var errors = response.getError();
                console.log(errors[0].message);
            }
        });
        $A.enqueueAction(getDesignationLevel);
    },
    getSelectedContactRecord: function (component, event) {
        //'0031s00000P4cDAAAZ'
        var getContactRecord = component.get("c.getContactSearchRecord");
        getContactRecord.setParams({
            "contactId": component.get('v.searchContactId')
        });
        getContactRecord.setCallback(this, function (response) {
            // alert("getContactRecord getState --->  "+response.getState());
            if (response.getState() == "SUCCESS") {
                //alert("getContactRecord getState --->  "+JSON.stringify(response.getReturnValue()));
                var sResponse = response.getReturnValue();
                console.log("sResponse ---> " + JSON.stringify(sResponse));
                // alert("getContactRecord Salutation__c --->  "+sResponse.Secondary_Salutation__c + " ssresult --> "+ssresult);
                
                // alert("getContactRecord Contact__c --->  "+sResponse.Id);
                // alert("getContactRecord lastname --->  "+sResponse.LastName);
                // alert("getContactRecord Date_of_Birth__c --->  "+sResponse.Date_of_Birth__c);
                var CourseRegistrationRecord = {
                    Salutation__c: sResponse.Salutation,
                    Contact__c: sResponse.Id,
                    First_Name__c: sResponse.FirstName,
                    Last_Name__c: sResponse.LastName,
                    Date_of_Birth__c: sResponse.Date_of_Birth__c,
                    Preferred_Certificate_Name__c: sResponse.Preferred_Certificate_Name__c,
                    Gender__c: sResponse.Gender__c,
                    Email_Address__c: sResponse.Email,
                    Mobile_No__c: sResponse.MobilePhone,
                    NRIC_Type__c: sResponse.NRIC_Type__c,
                    NRIC__c: sResponse.NRIC__c,
                    Nationality__c: sResponse.Nationality__c,
                    Office_No__c: sResponse.Mobile_Number__c,
                    Employment_Status__c: sResponse.Employment_Status__c,
                    Job_Title__c: sResponse.Title,
                    Designation_Level__c: sResponse.Designation_Level__c,
                    PDPA_Consent_Clause__c: sResponse.PDPA_Consent_Clause__c,
                    Marketing_Consent_Clause__c: sResponse.Marketing_Consent_Clause__c,
                };
                var lookupContactList = component.get("v.lookupContactId");
                lookupContactList.push(sResponse.Id);
                component.set("v.lookupContactId", lookupContactList);
                component.set("v.EditCourseRegistrationList", CourseRegistrationRecord);
                console.log("on lookup--> " + JSON.stringify(component.get("v.EditCourseRegistrationList")))
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                                    errors[0].message);
                        helper.ShowToastEvent(component, event, errors[0].message, 'Error', 'error');
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(getContactRecord);
    },
    getContactAction: function (component, event) {
        var getContactAction = component.get('c.getContactRecord');
        getContactAction.setCallback(this, function (response) {
            console.log(' 945 getState  --> ' + response.getState())
            if (response.getState() === "SUCCESS") {
                console.log(' 947 varContactInfowrapper  --> ' + response.getReturnValue())
                if (!$A.util.isEmpty(response.getReturnValue())) {
                    var varContactInfowrapper = response.getReturnValue();
                    component.set("v.contactRecord", varContactInfowrapper.objContact);
                    //contactInfowrapper 
                    component.set("v.contactInfowrapper", response.getReturnValue());
                    var contactRecord = component.get("v.contactRecord");
                    // alert(" is memberCheckbox ---> "+contactRecord.Account.Membership_Active__c);
                    // alert('Account id --> '+contactRecord.Account.Id)
                    component.set("v.accid", contactRecord.Account.Id);
                    component.set("v.memberCheckbox", contactRecord.Account.Membership_Active__c); //Changed to if Membership No is populated  
                }
            }
        });
        $A.enqueueAction(getContactAction);
    },
    getDraftRegistrationsPE: function (component, event, courseRunId) {
        
        var checkRegistration = component.get('c.getDraftRegistrations');
        checkRegistration.setParams({
            "courseRunid": courseRunId,
            "ContactId": $A.util.isEmpty(component.get('v.searchContactPE')) ? '' : component.get('v.searchContactPE')
        });
        checkRegistration.setCallback(this, function (response) {
            console.log(' 985 In getDraftRegistrations ' + response.getState());
            console.log(response.getReturnValue())
            if (response.getState() === "SUCCESS") {
                var courseRegId = response.getReturnValue();
                console.log('688 courseRegId --> ' + JSON.stringify(courseRegId))
                if (!$A.util.isEmpty(courseRegId)) {
                    component.set("v.CourseRegistrationMasterId", courseRegId[0].Parent_Registration__c);
                    component.set("v.courseRegistrationId", courseRegId[0].Parent_Registration__c);
                    component.set("v.editPdpa", courseRegId[0].PDPA_Consent_Clause__c);
                    component.set("v.editMarketing", courseRegId[0].Marketing_Consent_Clause__c);
                    // component.find("PromoCode").set("v.value",courseRegId[0].Promo_Code__r.Name);
                    
                    
                    var icountNeedUsrAcc = 0;
                    var updatedcourseReg = [];
                    // var existingCourseRegistration = component.get("v.CourseRegistrationList");
                    for (var i = 0; i < courseRegId.length; i++) {
                        if (!$A.util.isEmpty(courseRegId[i].Need_User_Account__c)) {
                            if (courseRegId[i].Need_User_Account__c == "Yes") {
                                courseRegId[i].isChecked = true;
                                icountNeedUsrAcc = icountNeedUsrAcc + 1;
                            }
                            else
                                courseRegId[i].isChecked = false;
                        }
                        updatedcourseReg.push(courseRegId[i]);
                    }
                    if (icountNeedUsrAcc == courseRegId.length) {
                        //alert(' 118 icountNeedUsrAcc --> '+icountNeedUsrAcc + ' courseRegId.length -> '+courseRegId.length)
                        
                    }
                    component.set("v.CourseRegistrationList", updatedcourseReg);
                    
                    
                    //-------MVP1.1: added by Devender:19th may 2021 for PE START -------
                    if (courseRegId[0].Learner_Fundings__r != undefined) {
                        var listCourseRegistrationforCheckGrant = component.get("v.CourseRegistrationList");
                        var updatedcourseRegforCheckGrant = [];
                        console.log('Learner_Fundings__r 0 --> ' + JSON.stringify(courseRegId[0].Learner_Fundings__r));
                        for (var i = 0; i < courseRegId.length; i++) {
                            if (courseRegId[i].Learner_Fundings__r != undefined) {
                                for (var j = 0; j < courseRegId[i].Learner_Fundings__r.length; j++) {
                                    console.log("existing id -> " + listCourseRegistrationforCheckGrant[i].Id);
                                    console.log("courseRegId id -> " + courseRegId[i].Learner_Fundings__r[j].Course_Registration__c);
                                    if (courseRegId[i].Id == courseRegId[i].Learner_Fundings__r[j].Course_Registration__c) {
                                        courseRegId[i].Learner_Funding_Amount__c = courseRegId[i].Learner_Fundings__r[j].Amount__c;
                                        courseRegId[i].SSGFundingType = courseRegId[i].Learner_Fundings__r[j].SSG_Funding_Types__c;
                                        courseRegId[i].LearnerFundingAmount = null;
                                        updatedcourseRegforCheckGrant.push(courseRegId[i]);
                                    }
                                    
                                }
                            } else {
                                updatedcourseRegforCheckGrant.push(courseRegId[i]);
                            }
                        }
                        component.set("v.CourseRegistrationList", updatedcourseRegforCheckGrant);
                    }
                    //-------MVP1.1: added by Devender:19th may 2021 for PE END -------
                    
                    console.log('1042 run' + component.get("v.isOpen"))
                    // component.set("v.CourseRegistrationList", courseRegId);
                    if (!component.get("v.isOpen")) {
                        //-------MVP1.1: added by Devender:19th may 2021 for Check Grant START -------
                        // i have put the if condition for checking the promo code length
                        if (courseRegId[0].Parent_Registration__r.Promo_Code__r != undefined) {
                            //-------MVP1.1: added by Devender:19th may 2021 for Check Grant END -------
                            var currentTab = component.get("v.selTabId");
                            component.set("v.selTabId", 'particulars');
                            console.log("Promo code --> " + courseRegId[0].Parent_Registration__r.Promo_Code__r.Name)
                            if (!$A.util.isEmpty(courseRegId[0].Parent_Registration__r.Promo_Code__r.Name)) {
                                var sPromoCode = courseRegId[0].Parent_Registration__r.Promo_Code__r.Name;
                                component.set("v.PromoCodeValue", sPromoCode);
                                if (!$A.util.isEmpty(sPromoCode)) {
                                    this.getPromoCode(component, event, sPromoCode).then(response => {
                                        console.log('returnFlag' + JSON.stringify(response));
                                    })
                                    }
                                    }
                                    }
                                    }
                                        console.log('1056 run')
                                    }
                                    }
                                        else {
                                        component.set("v.CourseRegistrationMasterId", "");
                                        component.set("v.courseRegistrationId", "");
                                        component.set("v.isOpen", false);
                                        component.set("v.isDeclareClose", true);
                                        
                                    }
                                    });
                                        $A.enqueueAction(checkRegistration);
                                    },
                                        getDuplicateUser: function (component, event, listemail) {
                                            
                                            var checkUserEmail = component.get('c.checkUserWithContact');
                                            checkUserEmail.setParams({
                                                "emailList": listemail
                                            });
                                            checkUserEmail.setCallback(this, function (response) {
                                                console.log('  In getDraftRegistrations ' + response.getState());
                                                console.log(JSON.stringify(response.getReturnValue()))
                                                if (response.getState() === "SUCCESS") {
                                                    var sMsgEmail = '';
                                                    if (!$A.util.isEmpty(response.getReturnValue())) {
                                                        for (var i = 0; i < response.getReturnValue().length; i++) {
                                                            sMsgEmail += response.getReturnValue()[i] + '\n';
                                                        }
                                                        if (!$A.util.isEmpty(sMsgEmail)) {
                                                            component.set("v.EmailError", true);
                                                        } else {
                                                            component.set("v.EmailError", false);
                                                        }
                                                    } else {
                                                        component.set("v.EmailError", false);
                                                    }
                                                }
                                            });
                                            $A.enqueueAction(checkUserEmail);
                                        },
                                        createModal: function (component, title, message, confirmHandler, showCancel) {
                                            //alert('in create model ')
                                            $A.createComponent(
                                                "c:Modal_Confirmation",
                                                {
                                                    "title": title,
                                                    "message": message,
                                                    "confirm": component.getReference(confirmHandler),
                                                    "showCancel": showCancel
                                                },
                                                function (modalWindow, status, errorMessage) {
                                                    // alert('in create model '+status+ '  modalWindow --> '+modalWindow)
                                                    if (status === "SUCCESS") {
                                                        var modalBody = component.set("v.modalBody", modalWindow);
                                                    }
                                                    else if (status === "INCOMPLETE") {
                                                        console.log("No response from server or client is offline.")
                                                        // Show offline error
                                                    }
                                                        else if (status === "ERROR") {
                                                            console.log("Error: " + errorMessage);
                                                            // Show error message
                                                        }
                                                }
                                            );
                                        },
                                        getPromoCode: function (component, event, promocode) {
                                            return new Promise($A.getCallback(function (resolve, reject) {
                                                component.set("v.Spinner", true);
                                                let masterRecordId = component.get("v.CourseRegistrationMasterId");
                                                console.log('masterRecordId' + masterRecordId);
                                                let promoCodeError = '';
                                                var getPromocodeRecord = component.get('c.getPromoCode');
                                                getPromocodeRecord.setParams({ promocode: promocode, courseId: component.get("v.courseId"), registrationStartDate: component.get("v.courseRunStartDate"), UserId: component.get("v.SelectedUserId"), masterRecId: masterRecordId });
                                                getPromocodeRecord.setCallback(this, function (response) {
                                                    console.log("getState ---> " + JSON.stringify(response.getState()))
                                                    if (response.getState() === "SUCCESS") {
                                                        component.set("v.Spinner", false);
                                                        console.log("getReturnValue ---> " + JSON.stringify(response.getReturnValue()));
                                                        if ($A.util.isEmpty(response.getReturnValue())) {
                                                            component.set("v.PromoCodeValue", "");
                                                            promoCodeError = 'Invalid PromoCode!';
                                                        } else {
                                                            var sResultJson = response.getReturnValue();
                                                            var promocodeRec = sResultJson.lstPromoCode;
                                                            var DiscountRec = sResultJson.lstDiscount;
                                                            var courseRegListSize = sResultJson.courseRegListSize;
                                                            let redemptionLimit = promocodeRec.Redemption_Limit__c;
                                                            let courseRegistrationList = component.get("v.CourseRegistrationList");
                                                            let courseRegListLength = courseRegistrationList.length;
                                                            let availableLimit = redemptionLimit - courseRegListSize;
                                                            console.log('courseRegListSize' + courseRegListSize + availableLimit + courseRegListLength + redemptionLimit);
                                                            if (redemptionLimit && availableLimit >= courseRegListLength || (redemptionLimit === undefined)) {
                                                                if (!$A.util.isEmpty(response.getReturnValue())) {
                                                                    var sResult = response.getReturnValue();
                                                                    var promocodeRec = sResult.lstPromoCode;
                                                                    var DiscountRec = sResult.lstDiscount;
                                                                    
                                                                    if (!$A.util.isEmpty(promocodeRec)) {
                                                                        component.set("v.PromoCodeDescription", !$A.util.isEmpty(promocodeRec.Description__c) ? promocodeRec.Description__c : '');
                                                                    }
                                                                    var finalAmount = 0;
                                                                    var iSalert = false;
                                                                    if (!$A.util.isEmpty(DiscountRec)) {
                                                                        var sMsg = '';
                                                                        console.log("DiscountRec.Discount__r.Percentage ---> " + DiscountRec[0].Discount__r.Percentage__c);
                                                                        if (DiscountRec[0].Discount__r.Percentage__c)
                                                                            sMsg = "An early bird discount of " + DiscountRec[0].Discount__r.GST_Amount__c + "% is applicable on this Course. \n If you wish to avail the early bird discount then remove the promo code.";
                                                                        else
                                                                            sMsg = "An early bird discount of $" + DiscountRec[0].Discount__r.Amount__c + " is applicable on this Course. \n If you wish to avail the early bird discount then remove the promo code.";
                                                                        component.set("v.discountMsg", sMsg);
                                                                    }
                                                                    console.log("CourseRecordType__c 1127 --->   " + component.get("v.courseRunRecord.CourseRecordType__c"));
                                                                    if (component.get("v.courseRunRecord.CourseRecordType__c") == "Funded_Course") {
                                                                        var FillfeePrice = component.get("v.MemberPriceFullfee");
                                                                        console.log("FillfeePrice       	 --->   " + FillfeePrice);
                                                                        console.log("Discount_Type__c   	 --->   " + promocodeRec.Discount_Type__c.trim().toUpperCase());
                                                                        console.log("Discount_Amount__c 	 --->   " + promocodeRec.Discount_Amount__c);
                                                                        console.log("Discount_Percentage__c --->   " + promocodeRec.Discount_Percentage__c);
                                                                        if (promocodeRec.Discount_Type__c.trim().toUpperCase() === "AMOUNT" && !$A.util.isEmpty(promocodeRec.Discount_Amount__c)) {
                                                                            finalAmount = FillfeePrice - promocodeRec.Discount_Amount__c;
                                                                            component.set("v.PromoCodeFullfeeValue", finalAmount.toString());
                                                                            component.set("v.PromoCodeId", promocodeRec.Id);
                                                                            component.set("v.PromoCodeApply", true);
                                                                            component.set("v.PromoCodeNonMemberValue", "");
                                                                            component.set("v.PromoCodeMemberValue", "");
                                                                            
                                                                        } else if (promocodeRec.Discount_Type__c.trim().toUpperCase() === "PERCENT" && !$A.util.isEmpty(promocodeRec.Discount_Percentage__c)) {
                                                                            var discountedPrice = (FillfeePrice * promocodeRec.Discount_Percentage__c) / 100;
                                                                            finalAmount = FillfeePrice - discountedPrice;
                                                                            component.set("v.PromoCodeFullfeeValue", finalAmount.toString());
                                                                            component.set("v.PromoCodeId", promocodeRec.Id);
                                                                            component.set("v.PromoCodeApply", true);
                                                                            component.set("v.PromoCodeNonMemberValue", "");
                                                                            component.set("v.PromoCodeMemberValue", "");
                                                                        } else {
                                                                            this.ShowToastEvent(component, event, $A.get("$Label.c.CourseRegistrationPromoCodeNullMsg"), 'Warning', 'warning');
                                                                            component.set("v.PromoCodeFullfeeValue", "");
                                                                            component.set("v.PromoCode", "");
                                                                            component.set("v.PromoCodeNonMemberValue", "");
                                                                            component.set("v.PromoCodeMemberValue", "");
                                                                            component.set("v.PromoCodeApply", false);
                                                                        }
                                                                        
                                                                    }
                                                                    else {
                                                                        if ((promocodeRec.Applicable_on__c.trim().toUpperCase() === "MEMBER PRICE" && component.get("v.memberCheckbox")) || (promocodeRec.Applicable_on__c.trim().toUpperCase() === "BOTH" && component.get("v.memberCheckbox"))) {
                                                                            var MemberPrice = component.get("v.MemberPrice");
                                                                            if (promocodeRec.Discount_Type__c.trim().toUpperCase() === "AMOUNT" && !$A.util.isEmpty(promocodeRec.Discount_Amount__c)) {
                                                                                finalAmount = MemberPrice - promocodeRec.Discount_Amount__c;
                                                                                component.set("v.PromoCodeMemberValue", finalAmount.toString());
                                                                                component.set("v.PromoCodeId", promocodeRec.Id);
                                                                                component.set("v.PromoCodeApply", true);
                                                                                component.set("v.PromoCodeNonMemberValue", "");
                                                                            }
                                                                            else if (promocodeRec.Discount_Type__c.trim().toUpperCase() === "PERCENT" && !$A.util.isEmpty(promocodeRec.Discount_Percentage__c)) {
                                                                                var discountedPrice = (MemberPrice * promocodeRec.Discount_Percentage__c) / 100;
                                                                                finalAmount = MemberPrice - discountedPrice;
                                                                                component.set("v.PromoCodeMemberValue", finalAmount.toString());
                                                                                component.set("v.PromoCodeId", promocodeRec.Id);
                                                                                component.set("v.PromoCodeApply", true);
                                                                                component.set("v.PromoCodeNonMemberValue", "");
                                                                            }
                                                                                else {
                                                                                    this.ShowToastEvent(component, event, $A.get("$Label.c.CourseRegistrationPromoCodeNullMsg"), 'Warning', 'warning');
                                                                                    component.set("v.PromoCodeMemberValue", "");
                                                                                    component.set("v.PromoCode", "");
                                                                                    component.set("v.PromoCodeId", "");
                                                                                    component.set("v.PromoCodeValue", "");
                                                                                    component.set("v.PromoCodeApply", false);
                                                                                }
                                                                        }
                                                                        else if ((promocodeRec.Applicable_on__c.trim().toUpperCase() === "NON-MEMBER PRICE" && !component.get("v.memberCheckbox")) || (promocodeRec.Applicable_on__c.trim().toUpperCase() === "BOTH" && !component.get("v.memberCheckbox"))) {
                                                                            var NonMemberPrice = component.get("v.NonMemberPrice");
                                                                            if (promocodeRec.Discount_Type__c.trim().toUpperCase() === "AMOUNT" && !$A.util.isEmpty(promocodeRec.Discount_Amount__c)) {
                                                                                finalAmount = NonMemberPrice - promocodeRec.Discount_Amount__c;
                                                                                component.set("v.PromoCodeNonMemberValue", finalAmount.toString());
                                                                                component.set("v.PromoCodeId", promocodeRec.Id);
                                                                                component.set("v.PromoCodeApply", true);
                                                                                component.set("v.PromoCodeMemberValue", "");
                                                                            }
                                                                            else if (promocodeRec.Discount_Type__c.trim().toUpperCase() === "PERCENT" && !$A.util.isEmpty(promocodeRec.Discount_Percentage__c)) {
                                                                                var discountedPrice = (NonMemberPrice * promocodeRec.Discount_Percentage__c) / 100;
                                                                                finalAmount = NonMemberPrice - discountedPrice;
                                                                                console.log('CNonMemberPrice==' + component.get('v.NonMemberPrice'));
                                                                                console.log('NonMemberPrice===' + NonMemberPrice);
                                                                                console.log('discountedPrice===' + discountedPrice);
                                                                                console.log('finalAmount===' + finalAmount);
                                                                                component.set("v.PromoCodeNonMemberValue", finalAmount.toString());
                                                                                component.set("v.PromoCodeId", promocodeRec.Id);
                                                                                component.set("v.PromoCodeApply", true);
                                                                                component.set("v.PromoCodeMemberValue", "");
                                                                            }
                                                                                else {
                                                                                    this.ShowToastEvent(component, event, $A.get("$Label.c.CourseRegistrationPromoCodeNullMsg"), 'Warning', 'warning');
                                                                                    component.set("v.PromoCodeNonMemberValue", "");
                                                                                    component.set("v.PromoCode", "");
                                                                                    component.set("v.PromoCodeId", "");
                                                                                    component.set("v.PromoCodeValue", "");
                                                                                    component.set("v.PromoCodeApply", false);
                                                                                }
                                                                        }
                                                                            else {
                                                                                component.set("v.PromoCodeNonMemberValue", "");
                                                                                component.set("v.PromoCode", "");
                                                                                component.set("v.PromoCodeId", "");
                                                                                component.set("v.PromoCodeValue", "");
                                                                                component.set("v.PromoCodeApply", false);
                                                                                this.ShowToastEvent(component, event, $A.get("$Label.c.CourseRegistrationPromoCodeNullMsg"), 'Warning', 'warning');
                                                                                
                                                                            }
                                                                    }
                                                                    // 2022-02-07 Daksh Mandowara : check condition for final discounted amount should not be negative
                                                                    
                                                                    let PromoCodeFullfeeValue = component.get("v.PromoCodeFullfeeValue");
                                                                    let PromoCodeNonMemberValue = component.get("v.PromoCodeNonMemberValue");
                                                                    let PromoCodeMemberValue = component.get("v.PromoCodeMemberValue");
                                                                    
                                                                    if( PromoCodeMemberValue && PromoCodeMemberValue < "0"){
                                                                        component.set("v.PromoCodeMemberValue","0");
                                                                    }
                                                                    if( PromoCodeNonMemberValue && PromoCodeNonMemberValue < "0"){
                                                                        
                                                                        component.set("v.PromoCodeNonMemberValue","0");
                                                                    }
                                                                    if( PromoCodeFullfeeValue && PromoCodeFullfeeValue < "0"){
                                                                        component.set("v.PromoCodeFullfeeValue","0");
                                                                    }
                                                                    // End changes by Daksh Mandowara
                                                                    
                                                                } else {
                                                                    component.set("v.PromoCodeNonMemberValue", "");
                                                                    component.set("v.PromoCode", "");
                                                                    component.set("v.PromoCodeId", "");
                                                                    component.set("v.PromoCodeValue", "");
                                                                    component.set("v.PromoCodeApply", false);
                                                                    this.ShowToastEvent(component, event, $A.get("$Label.c.CourseRegistrationPromoCodeNullMsg"), 'Warning', 'warning');
                                                                    
                                                                }
                                                            } else {
                                                                promoCodeError = `Promo code couldn't be applied to all the learners as available redemption limit ${availableLimit} is greater than number of learners in the list, please reach out to SIM for more`;
                                                            }
                                                        }
                                                        resolve({ 'errorFlag': promoCodeError !== '' ? true : false, 'errorMessage': promoCodeError });
                                                    } else if (state === "ERROR") {
                                                        component.set("v.Spinner", false);
                                                        var errors = response.getError();
                                                        console.log(" 532 Error message: " + errors);
                                                        if (errors) {
                                                            if (errors[0] && errors[0].message) {
                                                                console.log("Error message: " + errors[0].message);
                                                                component.set("v.PromoCodeNonMemberValue", "");
                                                                component.set("v.PromoCode", "");
                                                                component.set("v.PromoCodeValue", "");
                                                                component.set("v.PromoCodeId", "");
                                                                this.ShowToastEvent(component, event, "Error occured! Please contact the system admin.", 'Warning', 'warning');
                                                            }
                                                        } else {
                                                            console.log("Unknown error");
                                                        }
                                                        reject({ 'errorFlag': true, 'errorMessage': null });
                                                    }
                                                });
                                                $A.enqueueAction(getPromocodeRecord);
                                            }));
                                        },
                                        //-------MVP1.1: added by Devender:19th may 2021 for Check Grant START -------
                                        checkGrantRequest: function (component, event) {
                                            console.log('checkGrantRequest UEN ' + component.get("v.contactRecord.Account.UEN_No__c"));
                                            console.log('checkGrantRequest UEN for PE ' + component.get('v.AccountUEN'))
                                            component.set("v.Spinner", true);
                                            var course = [];
                                            course = {
                                                startDate: component.get("v.courseRunRecord").Start_Date__c,
                                                referenceNumber: component.get("v.courseRunRecord").Course__r.SSG_Course_Reference_Number__c
                                            };
                                            var CourseRegistrationList = component.get("v.CourseRegistrationList");
                                            var trainee = [];
                                            if (CourseRegistrationList.length > 0) {
                                                for (var i = 0; i < CourseRegistrationList.length; i++) {
                                                    if (CourseRegistrationList[i].NRIC_Type__c == "Singapore Citizen/PR") {
                                                        var CourseRegistrationRecord = {
                                                            id: CourseRegistrationList[i].NRIC__c,
                                                            idType: 'NRIC',
                                                            dateOfBirth: CourseRegistrationList[i].Date_of_Birth__c,
                                                            sponsoringEmployerUen: (!$A.util.isEmpty(component.get("v.contactRecord.Account.UEN_No__c")) ? (component.get("v.contactRecord.Account.UEN_No__c")) : '' || !$A.util.isEmpty(component.get('v.AccountUEN')) ? (component.get('v.AccountUEN')) : '')
                                                        };
                                                        trainee.push(CourseRegistrationRecord);
                                                    }
                                                }
                                            }
                                            
                                            var Request = [];
                                            Request = {
                                                course: course,
                                                trainee: trainee
                                            };
                                            console.log("Request " + JSON.stringify(Request))
                                            if (!$A.util.isEmpty(Request)) {
                                                var action = component.get("c.checkGrants");
                                                action.setParams({
                                                    requestWrap: Request
                                                });
                                                action.setCallback(this, function (response) {
                                                    console.log("getState " + response.getState())
                                                    console.log("getReturnValue " + JSON.stringify(response.getReturnValue()))
                                                    if (response.getState() == 'SUCCESS') {
                                                        component.set("v.Spinner", false);
                                                        component.set("v.mapCheckGrant", response.getReturnValue());
                                                        var fundingList = [];
                                                        var map = component.get("v.mapCheckGrant");
                                                        //console.log("value --> "+ map['S7099217E'].totalAMt);
                                                        console.log('map ' + JSON.stringify(map));
                                                        var existingCourseRegistration = component.get("v.CourseRegistrationList");
                                                        for (var i = 0; i < existingCourseRegistration.length; i++) {
                                                            console.log(i + 'cr .NRIC__c ' + existingCourseRegistration[i].NRIC__c);
                                                            console.log(i + 'cr .map ' + map[existingCourseRegistration[i].NRIC__c]);
                                                            if (map[existingCourseRegistration[i].NRIC__c] != undefined) {
                                                                //console.log("SSGFundingTypes -->> "+map[existingCourseRegistration[i].NRIC__c].SSGFundingTypes);
                                                                if (existingCourseRegistration[i].NRIC__c == map[existingCourseRegistration[i].NRIC__c].NirdId) {
                                                                    if (map[existingCourseRegistration[i].NRIC__c].totalAMt > 0) {
                                                                        existingCourseRegistration[i].Learner_Funding_Amount__c = map[existingCourseRegistration[i].NRIC__c].totalAMt;
                                                                        existingCourseRegistration[i].SSGFundingType = map[existingCourseRegistration[i].NRIC__c].SSGFundingTypes;
                                                                    }
                                                                    if (map[existingCourseRegistration[i].NRIC__c].totalAMt <= 0 && map[existingCourseRegistration[i].NRIC__c].status == 'Error') {
                                                                        existingCourseRegistration[i].LearnerFundingAmount = map[existingCourseRegistration[i].NRIC__c].message;
                                                                        existingCourseRegistration[i].Learner_Funding_Amount__c = 0;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        console.log('map 1354 ');
                                                        component.set("v.CourseRegistrationList", existingCourseRegistration);
                                                    } else if (state === "ERROR") {
                                                        component.set("v.Spinner", false);
                                                        var errors = response.getError();
                                                        console.log(" 1355 Error message: " + errors);
                                                        if (errors) {
                                                            if (errors[0] && errors[0].message) {
                                                                console.log("Error message: " + errors[0].message);
                                                                this.ShowToastEvent(component, event, "Error occured! Please contact the system admin.", 'Warning', 'warning');
                                                            }
                                                        } else {
                                                            console.log("Unknown error");
                                                        }
                                                    }
                                                });
                                                $A.enqueueAction(action);
                                            }
                                        },
                                        //-------MVP1.1: added by Devender:19th may 2021 for Check Grant END -------
                                        
                                        
                                        //-------MVP1.1: added by Devender:1th June 2021 for NRIC Validation START -------
                                        getNRICDetails: function (component, event) {
                                            var action = component.get("c.validateNRICValue");
                                            action.setCallback(this, function (response) {
                                                console.log(" 1321 getState " + response.getState())
                                                console.log(" 1322 getReturnValue " + JSON.stringify(response.getReturnValue()))
                                                if (response.getState() == 'SUCCESS') {
                                                    
                                                    component.set("v.mapNRICGrid", response.getReturnValue().nricMap);
                                                    component.set("v.mapNRICGridF", response.getReturnValue().nricMapone);
                                                    console.log(" 1325 Map getReturnValue nricMap " + JSON.stringify(component.get("v.mapNRICGrid")));
                                                    console.log(" 1325 Map getReturnValue nricMapone " + JSON.stringify(component.get("v.mapNRICGridF")));
                                                }
                                                else if (state === "ERROR") {
                                                    component.set("v.Spinner", false);
                                                    var errors = response.getError();
                                                    console.log(" 1355 Error message: " + errors);
                                                    if (errors) {
                                                        if (errors[0] && errors[0].message) {
                                                            console.log("Error message: " + errors[0].message);
                                                            this.ShowToastEvent(component, event, "Error occured! Please contact the system admin.", 'Warning', 'warning');
                                                        }
                                                    } else {
                                                        console.log("Unknown error");
                                                    }
                                                }
                                            });
                                            $A.enqueueAction(action);
                                        }
                                        //-------MVP1.1: added by Devender:1th June 2021 for NRIC Validation END -------
                                    })