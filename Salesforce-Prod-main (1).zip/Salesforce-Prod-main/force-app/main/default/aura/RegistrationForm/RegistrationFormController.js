({
	//2021-06-28 Poon Koon: Add in onInit method to read URL parameter and get redirecturl if any
	onInit : function(component, event, helper) {
        //console.log(document.referrer);
        
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); //You get the whole decoded URL of the page.
        var sURLVariables = sPageURL.split('&'); //Split by & so that you get the key value pairs separately in a list
        var sParameterName;
        var i;

        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split(/=(.+)/); //to split the key from the value.

            if (sParameterName[0] === 'redirecturl') {
                sParameterName[1] === undefined ? 'Not found' : sParameterName[1];
				component.set("v.redirecturl", sParameterName[1]);
            }
        }
        //console.log('Param name: '+sParameterName[0]);
        //console.log('Param value: '+sParameterName[1]);
    },
	signup : function(component, event, helper) {
		//2021-07-28 Poon Koon: Update all fields to report validity
		var firstName = component.find("firstName").get("v.value");
		var allValid = component.find("firstName").get("v.validity").valid;
		component.find("firstName").reportValidity();
		var lastName = component.find("lastName").get("v.value");
		allValid = allValid && component.find("lastName").get("v.validity").valid;
		component.find("lastName").reportValidity();
		var email = component.find("email").get("v.value");
		allValid = allValid && component.find("email").get("v.validity").valid;
		component.find("email").reportValidity();
		//2021-07-27 Poon Koon: Read password and store locally
		var password = component.find("password").get("v.value");
		allValid = allValid && component.find("password").get("v.validity").valid;
		component.find("password").reportValidity();
		allValid = allValid && component.find("confirmpassword").get("v.validity").valid;
		component.find("confirmpassword").reportValidity();
		var uenNo = "";
		var companyName = "";
		var corpAcct = component.get("v.corporateAccount");
		if (corpAcct) {
			uenNo = component.find("uenNo").get("v.value");
			allValid = allValid && component.find("uenNo").get("v.validity").valid;
			component.find("uenNo").reportValidity();
			companyName = component.find("companyName").get("v.value");
			allValid = allValid && component.find("companyName").get("v.validity").valid;
			component.find("companyName").reportValidity();
		}
        if (allValid) {
            //Black out curtain for please wait
            //Queue
            component.set('v.disabled', true);
			component.set('v.btnMessage', 'Processing');
			var createUser = component.get('c.createUser');
			createUser.setParams({firstName : firstName, lastName : lastName, email : email, corpAcct: corpAcct, uenNo : uenNo, companyName : companyName });
			createUser.setCallback(this, function(response) { 
				if(response.getState() === "SUCCESS") { 
					var result = response.getReturnValue();
					if (result == "Existing User") {
						component.set("v.result", result);
						helper.createModal(component, "Account already exists", "Your email address is currently in use", "c.handleConfirm", false);
					}
					else if (result == "Account Insert Error" || result == "Contact Insert Error" || result == "User Callout Error") {
						component.set("v.result", result);
						helper.createModal(component, "Error", "We encountered an unexpected error while creating an account for you. Please try again or reach out to us for assistance", "c.handleConfirm", false);
					}
					else {
						//2021-07-27 Poon Koon: Send password to backend
						var userCallout = component.get('c.userCallout');
						userCallout.setParams({ userId : result, password : password });
						userCallout.setCallback(this, function(response) { 
							var resultCallout = response.getReturnValue();
							component.set("v.result", resultCallout);
							if (resultCallout == "Success") {
								helper.createModal(component, "Account created", "Your account has been created. You will now be redirected to login screen.", "c.handleConfirm", false);
							}
							else {
								helper.createModal(component, "Error", "We encountered an unexpected error while creating an account for you. Please try again or reach out to us for assistance", "c.handleConfirm", false);
							}
						});
			
						$A.enqueueAction(userCallout);
					}
				}
				else {
					console.log(response.getError());
					console.log(response);
				}
			}); 
			
			$A.enqueueAction(createUser);
        } else {
			//Add Modal
			//helper.createModal(component, "Error", "Please complete all of the fields in the Registration Form", "c.handleConfirm", false);
        }

		
	},
	handleOnChange : function (component, event) {
		var name = event.getSource().get("v.name");
		if (name == "chkCorpAcct") {
			var corpAcct = component.get("v.corporateAccount");
			component.set("v.corporateAccount", !corpAcct);
		}
	},
	handleConfirm : function (component) {
		var result = component.get("v.result");
		//Redirect to Login
		var address = '/s';
		
		//2021-06-29 Poon Koon: Go to redirecturl if exists
		var redirecturl = component.get("v.redirecturl");
		if(redirecturl !== undefined && redirecturl !=='') {
			address = redirecturl;
		}

		var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
			"url": address,
			"isredirect" :false
		});
		//2021-06-29 Poon Koon: Perform either redirect or history back
        if(document.referrer === '') {
            //if referrer is empty (new window opened for the form),
            //redirect to the redirecturl or portal homepage (if no redirecturl)
            urlEvent.fire();
        }
        else {
            //if there is referrer (coming from another page such as Azure B2C),
            //go back there
            window.history.back();
        }
	},
	//2021-07-28 Poon Koon: Onchange verify confirm password
	onChangeVerifyConfirmPassword : function (component) {
		var password = component.find("password").get("v.value");
		var confirmpassword = component.find("confirmpassword").get("v.value");
		if(password!==confirmpassword) {
			component.find("confirmpassword").setCustomValidity("Password does not match.");
		}
		else {
			component.find("confirmpassword").setCustomValidity("");
		}
		component.find("confirmpassword").reportValidity();
	},
	//2021-07-30 Poon Koon: Onchange verify password complexity
	onChangeVerifyPasswordComplexity : function (component) {
		var password = component.find("password").get("v.value");
		var confirmpassword = component.find("confirmpassword").get("v.value");
		var re = RegExp("^((?=.*[a-z])(?=.*[A-Z])(?=.*\\d)|(?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9])|(?=.*[a-z])(?=.*\\d)(?=.*[^A-Za-z0-9])|(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]))([A-Za-z\\d@#$%^&amp;*\\-_+=[\\]{}|\\\\:',?/`~&quot;();!]|\\.(?!@)){8,64}$");
		if(!re.test(password)) {
			component.find("password").setCustomValidity("Your entry does not match the allowed pattern.");
		}
		else {
			component.find("password").setCustomValidity("");
			//re-check the Confirm Password if password is OK
			if(confirmpassword!=='') {
				if(password!==confirmpassword) {
					component.find("confirmpassword").setCustomValidity("Password does not match.");
				}
				else {
					component.find("confirmpassword").setCustomValidity("");
				}
				component.find("confirmpassword").reportValidity();
			}
		}
		component.find("password").reportValidity();
	}
})