({
    selectCourseRun: function(component, event, helper) {
        // call the event
        var cmpEvent = component.getEvent("myEvent");
        component.set("v.courseRun",component.get("v.con").Id)
        console.log("getSelecteContact"+ JSON.stringify(component.get("v.con")));
        console.log('line 8'+ component.get("v.courseRun"));
        // Pass the selected result(i.e Contact) value
        cmpEvent.setParams({
            "contactByEvent": component.get("v.con")
        });
        // Fire an Event
        cmpEvent.fire();
    }
})