({
	helperSubmitPublish: function(component,event) {
        component.set("v.showSpinner",true);
		var action = component.get("c.submitRequestPublish");
        action.setParams({
            'courseRunId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue().includes("SUCCESS")){
                component.set("v.showSpinner",false);
                component.set("v.isOpen", true);
                component.set("v.successMsg",$A.get("$Label.c.Success_Message_SSGIntegration"));
            }else{
                component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_Integration"));
            }
        });
        
        $A.enqueueAction(action);
	},
    helperSubmitUnPublish: function(component,event) {
        component.set("v.showSpinner",true);
        component.set("v.confirmation",false);
		var action = component.get("c.submitRequestUnPublish");
        action.setParams({
            'courseRunId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue().includes("SUCCESS")){
                component.set("v.showSpinner",false);
                component.set("v.isOpen", true);
                component.set("v.successMsg",$A.get("$Label.c.Success_Message_SSGIntegration"));
            }else{
                component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_Integration"));
            }
        });
        
        $A.enqueueAction(action);
	},
    helperSubmitSynchEnrollment: function(component,event,helper) {
        component.set("v.showSpinner",true);
		var action = component.get("c.submitRequestSynchEnrolment");
        action.setParams({
            'courseRunId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue().includes("SUCCESS")){
                component.set("v.showSpinner",false);
                component.set("v.isOpen", true);
                component.set("v.successMsg", $A.get("$Label.c.Success_Message_SSGIntegration"));
            }else if(response.getState()=="SUCCESS" && response.getReturnValue().includes("No Registration")){
                component.set("v.showSpinner",false);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type":'error',
                    "title":'Error!',
                    "message": $A.get("$Label.c.Course_registration_Missing_Validation")
                });
                toastEvent.fire();
                //this.helperCallToastMsg(componet,event,'Error!','error','There is no Course registration');
            }else{
                component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_Integration"));
            }
        });
        
        $A.enqueueAction(action);
	},
    helperSubmitSyncAttendance: function(component,event) {
        component.set("v.showSpinner",true);
		var action = component.get("c.submitRequestSynchAttendance");
        action.setParams({
            'courseRunId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue().includes("SUCCESS")){
                component.set("v.showSpinner",false);
                component.set("v.isOpen", true);
                component.set("v.successMsg", $A.get("$Label.c.Success_Message_SSGIntegration")
);
            }else{
                component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_Integration"));
            }
        });
        
        $A.enqueueAction(action);
	},
    helperSubmitCheckGrants: function(component,event) {
        component.set("v.showSpinner",true);
		var action = component.get("c.submitRequestCheckGrant");
        action.setParams({
            'courseRunId': component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            if(response.getState()=="SUCCESS" && response.getReturnValue().includes("SUCCESS")){
                component.set("v.showSpinner",false);
                component.set("v.isOpen", true);
                component.set("v.successMsg", $A.get("$Label.c.Success_Message_SSGIntegration"));
            }else if(response.getState()=="SUCCESS" && response.getReturnValue().includes("No Registration")){
                component.set("v.showSpinner",false);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type":'error',
                    "title":'Error!',
                    "message": $A.get("$Label.c.Course_registration_Missing_Validation")
                });
                toastEvent.fire();
                //this.helperCallToastMsg(componet,event,'Error!','error','There is no Course registration');
            }else{
                component.set("v.showSpinner",false);
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_Integration"));
            }
        });
        
        $A.enqueueAction(action);
	},
    /*getRecord:function(component,event){
        var action=component.get("c.getCourseRunRec");
        action.setParams({
            'courseRunId':component.get("v.recordId") 
        });
        action.setCallback(this,function(response){
            console.log(response.getState());
            if(response.getState()=='SUCCESS'){
                if(response.getReturnValue() != null){
                    component.set("v.courseRunRec",response.getReturnValue());
                }   
            }
        });
        $A.enqueueAction(action);
    },*/
    helperCallToastMsg:function(component,event,title,errorType,errorMsg){
        var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type":errorType,
                "title":title,
                "message": errorMsg
            });
            toastEvent.fire();  
    }
})