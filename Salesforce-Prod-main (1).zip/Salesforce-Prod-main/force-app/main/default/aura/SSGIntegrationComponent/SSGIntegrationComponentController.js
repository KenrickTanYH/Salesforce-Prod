({
    initialize : function(component, event, helper) {
       // helper.getRecord(component,event);
	},
    
	saveRequest : function(component, event, helper) {
         var action=component.get("c.getCourseRunRec");
        action.setParams({
            'courseRunId':component.get("v.recordId") 
        });
        action.setCallback(this,function(response){
            if(response.getState()=='SUCCESS'){
                if(response.getReturnValue() != null){
                component.set("v.courseRunRec",response.getReturnValue());
                if(event.getSource().get("v.name")=='PublishToTPG'){
                    var errorMsg ='';
                    if(component.get("v.courseRunRec").Room__c == null || component.get("v.courseRunRec").Room__c == ''){
                        errorMsg+=$A.get("$Label.c.Venue_Room_Validation")+'\n';
                    }
                    if(component.get("v.courseRunRec").Floor__c == null || component.get("v.courseRunRec").Floor__c == ''){
                         errorMsg+=$A.get("$Label.c.Venue_Floor_Validation")+'\n';
                    }
                    if(component.get("v.courseRunRec").Unit__c == null || component.get("v.courseRunRec").Unit__c == ''){
                        errorMsg+= $A.get("$Label.c.Venue_Unit_Validation")+'\n';
                    }
                    if(component.get("v.courseRunRec").Postal_Code__c == null || component.get("v.courseRunRec").Postal_Code__c == ''){
                       errorMsg +=$A.get("$Label.c.Venue_PostalCode_Validation");
                    }
                    if(errorMsg != '' && errorMsg != null){
                        helper.helperCallToastMsg(component, event,'Error!','error',errorMsg);
                        return;
                    }
                        if(component.get("v.courseRunRec").Course__r.SSG_Course_Reference_Number__c != null 
                           && component.get("v.courseRunRec").Course__r.SSG_Course_Reference_Number__c !=''){
                            if(component.get("v.courseRunRec").Course_Sessions__r != null){
                                helper.helperSubmitPublish(component, event);   
                            }else{
                                helper.helperCallToastMsg(component, event,'Error!','error',$A.get("$Label.c.Session_Record_Validation"));
                            }  
                        }else{
                            helper.helperCallToastMsg(component, event,'Error!','error',$A.get("$Label.c.Course_reference_Number_Validation"));
                        }
                    
                }
                if(component.get("v.courseRunRec").SSG_Course_Run_ID__c != null && component.get("v.courseRunRec").SSG_Course_Run_ID__c !=''){
                    if(event.getSource().get("v.name")=='UnpublishFromTPG'){
                        component.set("v.confirmation",true);
                        component.set("v.confirmationMsg",$A.get("$Label.c.confirmationMSGUnpublish"));
                    }else if(event.getSource().get("v.name")=='SyncEnrollment'){
                        helper.helperSubmitSynchEnrollment(component, event,helper);
                    }else if(event.getSource().get("v.name")=='SyncAttendance'){
                        helper.helperSubmitSyncAttendance(component, event);
                    }else if(event.getSource().get("v.name")=='CheckGrants'){
                        helper.helperSubmitCheckGrants(component, event);
                    }
                }else{
                    if(event.getSource().get("v.name") !='PublishToTPG'){
                        helper.helperCallToastMsg(component, event,'Error!','error',$A.get("$Label.c.SSG_Course_Run_ID_Validation"));   
                    }
                }
                }   
            }else{
                console.log('----Msg----'+response.getReturnValue());
                component.set("v.isError",true);
                component.set("v.errorMsg", $A.get("$Label.c.Error_Message_SSG_Integration"));
            }
        });
        $A.enqueueAction(action);
	},
    closeModel: function(component, event, helper) {
      // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpen", false);
        component.set("v.isError",false);
        component.set("v.confirmation",false);
   },
    saveReqUnpublish:function(component, event, helper) {
        helper.helperSubmitUnPublish(component, event);
   }
})